# Hover reveal effect

- **Category:** Animation
- **Slug:** `hover-reveal-effect`
- **Target AI Tools:** Cursor, Claude 3.7 / 3.5 Sonnet, Bolt.new, v0.dev, Windsurf, Lovable
- **Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)
- **Tags:** landing page, hover effect, animation

---

## Architectural Philosophy & Overview
Source: https://x.com/emilylambert/status/2005113433780617713

---

## Production System Prompt Specification
```
I want to create a personal portfolio landing page for \[YOUR NAME\]. The page should be a full-screen hero section with a large headshot image \[IMAGE ONE\] as the background, centered and covering the entire viewport. My name should appear in the top left corner in a large, elegant serif font (like Playfair Display) with the first and last name stacked on separate lines. In the top right corner, add a "Portfolio" link. At the bottom right, include social media icons for Instagram, X/Twitter, YouTube, and LinkedIn that link to my profiles - use solid filled SVG icons so they're clearly visible.\
\
The main interactive feature should be a blob cursor effect that follows the mouse. When the user hovers over the page, an organic, gooey blob shape should appear and follow the cursor with a slight lag for a smooth, fluid feel. This blob should act as a "reveal" mask that shows a second version of the headshot \[IMAGE TWO\] - so as the user moves their cursor around, they're essentially revealing an alternate image underneath. The blob should have a trailing effect where smaller, fading blob shapes follow behind based on cursor speed - faster movement creates more pronounced trails. Add subtle animated wave lines in the background that respond gently to mouse movement.\
\
All text elements (my name, the Portfolio link, and the social icons) should dynamically invert to white when the blob cursor hovers over them, so they remain visible against the revealed image. The transitions should be smooth with a 300ms duration. Add a subtle parallax effect where elements shift slightly in the opposite direction of cursor movement to create depth. The overall aesthetic should be minimal and sophisticated with a white background, letting the photography and interactive elements be the focal point.
```
