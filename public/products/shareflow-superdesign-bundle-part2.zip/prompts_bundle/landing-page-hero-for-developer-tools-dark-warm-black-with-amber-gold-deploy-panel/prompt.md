# Landing Page Hero for Developer Tools - Dark Warm-Black with Amber-Gold Deploy Panel

- **Category:** Style
- **Slug:** `landing-page-hero-for-developer-tools-dark-warm-black-with-amber-gold-deploy-panel`
- **Target AI Tools:** Cursor, Claude 3.7 / 3.5 Sonnet, Bolt.new, v0.dev, Windsurf, Lovable
- **Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)
- **Tags:** landing, landing-page, hero, marketing, marketing-site, developer-tool, devtool, infrastructure, infra, saas, product-landing, dark, dark-mode, dark-theme, near-black, warm-black, amber, gold, one-accent, single-accent, monochrome, neutral, glow, grain, cinematic, restrained, quiet-luxury, floating-nav, pill-nav, space-grotesk, jetbrains-mono, grotesk, mono, deploy-panel, terminal-panel, cli, install-command, sparkline, trusted-by, high-contrast, responsive, desktop, minimal

---

## Architectural Philosophy & Overview
A premium dark developer-tool and infrastructure landing page hero on a warm near-black canvas where a single amber-gold accent does all the work. Space Grotesk carries a big two-line headline over a quiet subtitle, JetBrains Mono handles the kicker, the npx install command and the product panel. A floating pill nav, a solid-amber primary CTA beside a ghost 'Read the docs' button, and a copyable install chip sit next to the copy-worthy signature: a floating live deploy panel with mono build steps, one amber 'Deployed to production' line, and a latency/uptime strip with an amber sparkline. A soft amber glow sits behind the text, everything else stays strictly neutral, and a trusted-by logo strip anchors the bottom. Fully responsive. Copy it for any dark SaaS, CLI, launcher, or API-product landing hero.

---

## Production System Prompt Specification
```
{
  "summary": "A premium DARK developer-tool / infrastructure product LANDING-PAGE HERO (1440-wide desktop, fully responsive) on a WARM near-black #0b0a08 canvas, built so a single amber-gold #f5b544 accent is the entire personality. Type is a grotesk + mono pairing, NOT Inter-only and NOT a serif: Space Grotesk does all display/UI (headline weight 600, letter-spacing -0.02em, line-height ~1.05) and JetBrains Mono is reserved for the kicker, the install command, and the product panel. Hierarchy comes from SIZE and WEIGHT. Top center: a FLOATING PILL NAV - a dark translucent (backdrop-blurred) rounded container with a 1px hairline border and a faint inner-top highlight, NOT a full-bleed bar - holding an amber rounded-square logo mark + off-white wordmark on the left, muted #8d887c 14px/500 center links (Product, Docs, Pricing, Changelog, Blog), and on the right a muted 'Sign in' plus a small amber-OUTLINE 'Get started' pill. The hero is an asymmetric split: on the LEFT a stack of (1) a JetBrains Mono AMBER uppercase letter-spaced KICKER ('SHIP FASTER . v2.0 NOW LIVE') with a small amber dot; (2) a two-line H1 in Space Grotesk ~62px/600 off-white #f6f3ec ('Deploy your backend in one command.'); (3) an 18px/400 muted-ink #8d887c subtitle, ~2 lines, max ~600px; (4) a CTA ROW - a PRIMARY solid amber pill 'Start building free' (dark #0b0a08 text on #f5b544, subtle raised amber shadow, trailing arrow) beside a GHOST pill 'Read the docs' (transparent, 1px off-white ring); (5) a JetBrains Mono muted INSTALL chip '$ npx create-forge@latest' with a small copy glyph. On the RIGHT, floating slightly higher, the SIGNATURE product panel (see components): a dark rounded card reading as a live deploy/CLI preview. A single soft amber RADIAL glow with a faint film-grain overlay fills the mid-canvas BEHIND the text as the ONLY chroma - no gradient-mesh, no second color. The bottom holds a muted 'Trusted by teams at' micro-label above a strip of monochrome low-opacity wordmarks. Everything is FLAT except the primary amber CTA (subtle raised shadow) and the floating panel (layered soft shadow + hairline). Amber is confined STRICTLY to the logo, the primary CTA, the glow, the kicker, one panel status dot + one panel log line, and one sparkline; every other pixel is #f6f3ec / #8d887c / #0b0a08. High-contrast, cinematic, restrained.",
  "style": {
    "description": "Cinematic dark RESTRAINT for a developer-infra marketing hero - a warm near-black #0b0a08 ground where ONE amber-gold #f5b544 accent is the only chroma and everything else is strictly neutral (#f6f3ec ink, #8d887c muted). A grotesk + mono pairing (Space Grotesk display, JetBrains Mono for technical text) replaces the AI-default Inter-only, and hierarchy comes from SIZE and WEIGHT: a big ~62px/600 off-white headline over a quiet 18px muted subtitle. The shape language is flat with two deliberate exceptions - the primary CTA is a solid amber pill with a subtle raised amber shadow, and the floating deploy panel carries a layered soft shadow, a 1px hairline border and a faint inner-top highlight. Chrome floats (a translucent hairline-bordered pill nav at top; a live product panel to the right). A single soft amber radial glow with faint film-grain sits behind the text; no gradient-mesh, no second accent, no photos. The amber accent is DISCIPLINED - logo, primary CTA, glow, kicker, one panel line + status dot, one sparkline, nothing more.",
    "prompt": "Design a premium DARK developer-tool / infrastructure LANDING-PAGE HERO for a 1440-wide desktop viewport (fully responsive) on a WARM near-black #0b0a08 canvas, making ONE amber-gold accent #f5b544 the entire personality. Use Space Grotesk for all display/UI (headline weight 600, letter-spacing -0.02em, line-height ~1.05) and JetBrains Mono ONLY for the kicker, the install command and the product panel - never Inter-only, never a serif. Build hierarchy from SIZE and WEIGHT: a big two-line H1 at ~62px/600 in off-white #f6f3ec over a quiet 18px/400 muted #8d887c subtitle. Paint a SINGLE soft amber RADIAL glow (amber core fading to #0b0a08) with a faint film-grain overlay behind the centered text as the only chroma - no gradient-mesh, no indigo/violet. Keep everything FLAT except the primary CTA (a solid amber pill, dark #0b0a08 text on #f5b544, a subtle raised amber shadow) and the floating deploy panel (layered soft shadow, 1px hairline border, faint inner-top highlight). Confine amber STRICTLY to the logo mark, the primary CTA, the glow, the kicker, one panel log line + status dot, and one sparkline; keep every other pixel strictly neutral (#f6f3ec / #8d887c / #0b0a08). No stock photos, no second accent color, high-contrast and cinematic."
  },
  "layout_and_structure": {
    "description": "An asymmetric single-viewport hero. Top center: a floating translucent PILL NAV (amber logo mark + wordmark left, muted center links, muted 'Sign in' + amber-outline 'Get started' pill right). Below, a two-column split: LEFT a stack of an amber mono kicker, a two-line ~62px/600 off-white headline, an 18px muted subtitle, a CTA row (solid amber primary + ghost secondary), and a mono install chip; RIGHT a floating dark deploy/CLI product panel sitting slightly higher. A soft amber radial glow with film-grain fills the mid-canvas behind the text. The bottom holds a 'Trusted by teams at' micro-label above a monochrome low-opacity wordmark strip. On mobile the nav collapses to logo + one CTA, the columns stack (text then panel), the headline steps to ~36px, and the CTA buttons go full-width.",
    "prompts": [
      {
        "part": "Floating pill nav",
        "prompt": "Pin a FLOATING PILL NAV near the top center: a dark translucent (backdrop-blurred) rounded container with a 1px hairline border and a faint inner-top highlight, NOT a full-width bar. Left: a small amber rounded-square logo mark next to an off-white ~600-weight wordmark. Center: muted #8d887c 14px/500 links (Product, Docs, Pricing, Changelog, Blog). Right: a muted 'Sign in' link and a small amber-OUTLINE 'Get started' pill. On mobile, drop the center links and keep just the logo + the 'Get started' pill."
      },
      {
        "part": "Kicker + headline + subtitle",
        "prompt": "LEFT column: start with a JetBrains Mono AMBER uppercase KICKER, letter-spacing ~0.18em, with a small amber dot (e.g. 'SHIP FASTER . v2.0 NOW LIVE'). Below it a two-line H1 in Space Grotesk ~62px / weight 600 / line-height ~1.05, off-white #f6f3ec (scope the size to a .hero-h1 class with !important so host CSS can't override it), e.g. 'Deploy your backend in one command.' Then an 18px / weight 400 muted #8d887c subtitle, ~2 lines, max ~600px."
      },
      {
        "part": "CTA row + install chip",
        "prompt": "Below the subtitle, a CTA ROW: a PRIMARY solid amber pill 'Start building free' (dark #0b0a08 text on #f5b544, fully rounded, a subtle raised amber shadow, a trailing arrow glyph) next to a GHOST pill 'Read the docs' (transparent fill, 1px off-white/20 ring, off-white text). Directly under the row, a small mono INSTALL chip: a #141210 rounded box with a 1px hairline border holding JetBrains Mono muted text '$ npx create-forge@latest' and a small copy glyph button. On mobile both CTA buttons go full-width and stack."
      },
      {
        "part": "Amber glow backdrop",
        "prompt": "Fill the mid-canvas behind the text with a SINGLE soft amber RADIAL glow (rgba(245,181,68,~0.15) core fading to #0b0a08 by ~60%) plus a faint film-grain overlay (a 1px radial-gradient dot pattern on a ~4px grid). Keep it soft-focus and desaturated at the edges so off-white text stays legible. This glow is the ONLY chroma in the composition - no gradient-mesh, no second color."
      },
      {
        "part": "Trusted-by strip",
        "prompt": "At the bottom center, a muted #8d887c uppercase micro-label 'Trusted by teams at' above a horizontal strip of 4-5 monochrome off-white wordmark/logo placeholders at low opacity (~40%). It should read as quiet social proof, wrapping on mobile."
      }
    ]
  },
  "special_ui_components": [
    {
      "component": "Floating live deploy / CLI product panel",
      "description": "A dark rounded card that floats beside the hero text reading as a live deploy/CLI preview - the hero's copy-worthy signature.",
      "prompt": "Build a FLOATING dark product panel (#141210, border-radius ~16px, 1px hairline border rgba(246,243,236,0.08), a layered soft drop-shadow and a faint inner-top highlight) that reads as a live deploy/CLI preview. Top window bar: three dim window dots on the left, a mono branch label in a small inset chip ('api-gateway/main') in the center, and on the right an amber 'live' status with a small glowing amber dot. Body in JetBrains Mono ~13px: a muted command line ('> forge deploy --prod') then a few muted step lines ('[1/4] Analyzing dependencies... 0.2s', etc.) where EXACTLY ONE line is amber ('Deployed to production'). Below, a metrics strip in an inset #0b0a08 box: two mono figures ('Latency 12ms', 'Uptime 99.99%') and a tiny amber SVG sparkline. Keep amber to the status dot, the one success line, and the sparkline only; everything else is neutral."
    },
    {
      "component": "Floating translucent pill nav",
      "description": "A rounded dark-glass nav container that floats near the top rather than spanning the full width.",
      "prompt": "Create a FLOATING PILL NAV: a dark translucent (backdrop-blurred #141210/60) rounded container with a 1px hairline border and a faint inner-top highlight, centered near the top with generous horizontal padding - NOT a full-bleed bar. Left: a small amber rounded-square logo glyph + off-white wordmark. Center: a row of muted #8d887c 14px/500 text links. Right: a muted secondary link and one small amber-outline pill CTA. It should look like it hovers above the dark hero, and collapse to logo + CTA on mobile."
    },
    {
      "component": "Amber SVG sparkline",
      "description": "A tiny single-amber metrics sparkline whose last point snaps to the plot's right edge.",
      "prompt": "Draw a small inline SVG sparkline in a ~96x32 box: a smooth amber #f5b544 stroke (~1.5px, non-scaling-stroke) with a soft amber-to-transparent fill under it, and a filled amber end-dot. ALWAYS include a viewBox matching the path's coordinate space and snap the LAST point onto the plot's right edge (no series ending short of its own last tick). Use it as a quiet latency/uptime trend inside a dark metrics strip - it is one of the few amber marks in the whole hero."
    },
    {
      "component": "Solid-amber primary CTA + ghost secondary",
      "description": "A disciplined two-button CTA pair: one solid amber pill, one transparent ghost pill.",
      "prompt": "Pair a PRIMARY solid amber pill button (dark #0b0a08 text on #f5b544, fully rounded, generous padding, a subtle raised amber shadow like 0 4px 14px rgba(245,181,68,0.25) that deepens on hover, a trailing arrow) with a GHOST secondary pill (transparent fill, a 1px off-white/20 ring, off-white text, hover to a faint off-white wash). Side by side on desktop, stacked full-width on mobile. The solid amber pill is the single most saturated element in the hero, so keep the ghost strictly neutral."
    }
  ]
}
```
