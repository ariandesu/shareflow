# Landing Page UI: Stage Lighting Studio Website Where Two Lamps Mix Every Colour on the Page

**Category:** Landing Page  
**Tags:** landing, landing-page, dark-mode, lighting, stage-lighting, event-production, local-business, service-business, additive-gel, mix-blend-mode, colour-system, magenta, cyan, navy, beams, flat-design, hard-edges, archivo, grotesque, desktop, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/c01941a2-4896-4460-93b7-da84237577aa](https://p.superdesign.dev/draft/c01941a2-4896-4460-93b7-da84237577aa)  
**Local Standalone Preview:** `previews/landing-page-ui-stage-lighting-studio-website-where-two-lamps-mix-every-colour-on-the-page.html`

---

## Architectural & Aesthetic Breakdown
A dark LANDING PAGE UI for a stage and event lighting studio with a colour system you can prove: the page is a dark stage (#14132b) lit by two lamps, a magenta gel #F42FCB and a cyan gel #1CB0F6, and every colour on it is one of the lamps, the pale orchid the two beams make where they physically cross (a real CSS mix-blend-mode screen overlap, computed by the browser, never hand painted), dim white for unlit things, or pure white meaning all the lamps are on. The colours carry the information: magenta marks show work, cyan marks room work, the overlap marks full production, and white is reserved for the booking CTA and the closing band. Two hard edged flat beam polygons cross in the hero under tiny labelled fixtures, with an equation chip reading swatch plus swatch equals the blended overlap. One tight grotesque (Archivo 500/600), 4px radii, zero gradients, zero glows, flat fills only. Reusable for any lighting, AV, event production or nightlife service business, and the two-lamp colour algebra transposes to any brand with two named accent colours.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A full scrolling LANDING PAGE for a stage and event lighting design studio ('Gelhouse', Manchester) built on one physical rule: the page is a dark stage (#14132b) lit by exactly two lamps, a magenta gel (#F42FCB) and a cyan gel (#1CB0F6), and every colour anywhere on the page is one of the lamps, the colour the two beams make where they physically cross (rendered with CSS mix-blend-mode: screen so the browser computes the additive mix as a pale orchid, never hand painted), white at reduced opacity for unlit things, or pure white meaning every lamp is on. The colours also carry the information architecture: magenta marks work about the show (design, cues, followspots, band looks), cyan marks work about the room (rig install, power, house wash, maintenance), the overlap colour marks work that is both, and pure white is reserved for the booking action and the closing band, so the primary CTA is literally the rig at full. Sections top to bottom: a compact masthead (white wordmark, dim nav, white CTA button); a hero where two hard edged FLAT beam polygons angle down from two tiny labelled fixture marks and cross mid page, the headline set across them in white ('We hang the lamps. The colours do the arguing.'), with a small equation chip proving the system (a magenta swatch, a plus, a cyan swatch, an equals, then one swatch made of two fully overlapped blended rects); a rig legend band stating the rule in plain copy with two gel spec rows printing their own hex values; services as two beam columns with numbered rows and one line descriptions; a full production band whose surface is the two colours genuinely overlapped by the blend, captioned in dark ink inside the overlap; a one venue case study with a cue sheet (19:30 house on a dim white chip, 20:15 first set on magenta, 23:00 late set on cyan) and a fixture count that adds up in front of you (8 on magenta, 4 on cyan, 12 total); three price cards keyed by gel chips with the flagship on a solid white card; a full bleed pure white closing band reading 'All the lamps on.' with a dark booking button; a dim footer. One typeface, Archivo at weights 500 and 600 only, hierarchy from scale, 4px radii, zero gradients, zero glows, zero shadows, flat fills only, at most four tracked uppercase labels on the whole page.",
  "style": {
    "description": "Additive-gel: a dark stage lit by its own two lamps. The ground is a near black navy #14132b and the only chroma comes from two gel colours, magenta #F42FCB and cyan #1CB0F6, applied as FLAT hard edged fills at around 0.8 opacity with mix-blend-mode: screen, so wherever two fills overlap the browser computes the brighter additive mix exactly the way two stage lights do. No gradients, no glows, no blooms, no shadows, no blur anywhere; the neon poster cliche is deliberately refused and the drama comes from hard geometry and honest colour arithmetic. Unlit text is white at 62 percent opacity, lit text is solid white, and pure white surfaces mean every lamp is on, which is why the CTA button, the flagship price card and the final band are the only white objects on the page. One tight modern grotesque (Archivo) does everything at weights 500 and 600 with tight negative tracking on the display sizes; radii are 4px; panels are the ground lifted by 4 to 6 percent white or a 1px white/14 border.",
    "prompt": "Design a dark landing page as a stage lit by exactly two lamps. Ground #14132b. Two gel colours only: magenta #F42FCB and cyan #1CB0F6. Apply them as flat hard edged shapes (clip-path polygons for beams, plain rectangles for chips and rules) at about 0.8 opacity with mix-blend-mode: screen inside an isolated stacking context, so overlapping shapes genuinely add to a brighter pale orchid computed by the browser; never hand paint the mix colour. Ban all gradients, glows, box shadows, text shadows and blurs; the page must read as flat print geometry, not neon bloom. Dim copy is rgba(255,255,255,0.62), lit copy is solid #ffffff, and pure white is reserved for the surfaces that mean all the lamps are on: the CTA buttons, the flagship price card and the full bleed closing band, which carry dark #14132b text. Use ONE typeface, Archivo, at weights 500 and 600 only, with letter-spacing about -0.03em on display sizes and hierarchy carried by scale. All radii 4px. Panels are rgba(255,255,255,0.05) fills or 1px rgba(255,255,255,0.14) borders on the ground. Ration tracked uppercase labels to at most four on the whole page."
  },
  "layout_and_structure": {
    "description": "Eight bands: (1) compact masthead, wordmark left, dim nav centre, white CTA right; (2) crossed beam hero, two flat beam polygons from tiny top fixtures crossing mid page, left set headline across them, sub line, white CTA, and an equation chip; (3) rig legend band, the rule in plain copy plus two gel spec rows with swatch, hex and role; (4) services as two columns, each opened by a thick gel rule and a title, four numbered rows with one line descriptions; (5) a full production band, two wide gel rectangles overlapping in the middle with the caption in dark ink inside the computed overlap; (6) case study, facts column left, cue sheet right with a coloured chip per cue; (7) three price cards keyed by gel chips, flagship on solid white; (8) full bleed white closing band plus a dim footer. Fully responsive: percentage clip-path coordinates keep the beams crossing at 390px, columns stack, nothing overflows.",
    "prompts": [
      {
        "part": "Masthead",
        "prompt": "A compact header on the dark ground: the wordmark in solid white 600 at the left, a centre nav of dim white links (Work, Services, Prices, Contact) that light to solid white on hover, and a white rectangular CTA button with dark #14132b text at the right, 4px radius."
      },
      {
        "part": "Crossed beam hero",
        "prompt": "A tall hero section with isolation: isolate and two absolutely positioned full size divs clipped to beam shapes: a magenta #F42FCB polygon (clip-path roughly 20% 0, 30% 0, 70% 100%, 0% 100%) and a cyan #1CB0F6 polygon (roughly 70% 0, 80% 0, 100% 100%, 30% 100%), both flat fills at 0.8 opacity with mix-blend-mode: screen so the crossing region turns pale orchid. At each beam apex place a tiny fixture: a small white rectangle, a 1px stem, and a tracked caps label ('LAMP 1 . MAGENTA GEL', 'LAMP 2 . CYAN GEL'). Over the beams, left aligned: a display headline in solid white 600 at clamp(44px, 7vw, 84px) with -0.03em tracking, sentence case ending in a period; a 19px semibold white sub line; a white CTA button; then the equation chip."
      },
      {
        "part": "Gel equation chip",
        "prompt": "An inline chip on a solid ground fill with a 1px white/14 border: a magenta swatch, a white plus sign, a cyan swatch, a white equals sign, then a single swatch made of two identical rects stacked inset-0 in an isolated box, one magenta and one cyan, both mix-blend-mode: screen at 0.8 opacity, so the result square IS the computed overlap colour. Caption in solid white: 'what the beams make where they cross'."
      },
      {
        "part": "Rig legend band",
        "prompt": "A band separated by 1px white/14 rules on a white/5 panel: one plain paragraph stating the system ('Magenta lights the show. Cyan lights the room. The crossing makes the third colour. Everything on makes white.'), then a two column grid of gel spec rows: a 48px flat swatch, the hex printed as text in white 600, and the role in dim white ('The show' / 'The room')."
      },
      {
        "part": "Two beam service columns",
        "prompt": "Two columns, each opened by an 8px tall full width gel rule (magenta left, cyan right) and a 2xl white 600 title ('The show' / 'The room'). Under each, four numbered rows: a dim number, a white service name, and a one line dim description under it. Keep the copy plain and specific, written like a working tech, no marketing cadence."
      },
      {
        "part": "Full production blend band",
        "prompt": "A full width band with isolation: isolate and two absolutely positioned rectangles: magenta from the left at 64% width, cyan from the right at 64% width, both flat at 0.9 opacity with mix-blend-mode: screen, so the middle 28% is the computed overlap. Centre the caption inside the overlap in dark #14132b: a semibold line ('Both at once: full production') and one plain sentence under it."
      },
      {
        "part": "Cue sheet case study",
        "prompt": "On a white/5 panel band: a heading naming one real feeling venue, a facts column (room, capacity, rig date, and a fixture count that adds up: '12 fixtures. 8 on the magenta circuit, 4 on cyan. 1 desk.'), and a cue list where each row has a 16px chip in the colour of that cue (dim white/20 for house, magenta for the first set, cyan for the late set), a white 600 time and cue name, and one dim sentence of what the room looks like. Times must be monotonic through the evening."
      },
      {
        "part": "Gel keyed price cards",
        "prompt": "Three cards: the first two on the dark ground with 1px white/14 borders, each keyed by a small flat gel chip (magenta for show work, cyan for room work), a white 600 service name and a large 'from' price with a dim unit. The third, flagship card is SOLID WHITE with dark text and both gel chips side by side: everything on, full production, from the highest price. Plain GBP numbers, no meters, no bars, no per feature grids."
      },
      {
        "part": "White closing band and footer",
        "prompt": "A full bleed pure white band with dark #14132b text: a large 600 heading ('All the lamps on.') and a dark rectangular button ('Book a walkthrough'). Then a minimal footer on the dark ground: studio name and address left, an email right, all in dim white."
      }
    ]
  },
  "special_ui_components": [
    {
      "component": "Screen-blend beam crossing",
      "description": "Two flat clip-path beam polygons whose overlap colour is computed by the browser.",
      "prompt": "Build two absolutely positioned full size divs inside an isolation: isolate container, each clipped to a narrow-topped beam polygon with percentage clip-path coordinates so the geometry survives every viewport width. Fill one #F42FCB and one #1CB0F6, both flat at 0.8 opacity with mix-blend-mode: screen and no gradients or blur, so the crossing region genuinely adds to a brighter pale orchid. Hard edges only; the beams must read as cut shapes, not glows."
    },
    {
      "component": "Gel equation chip",
      "description": "A small proof that the palette is arithmetic: swatch plus swatch equals the live blended overlap.",
      "prompt": "Compose an inline chip: an 8x8 magenta swatch, a plus, an 8x8 cyan swatch, an equals, then an 8x8 isolated box containing two inset-0 layers, one magenta and one cyan, both mix-blend-mode: screen at 0.8 opacity, so the third swatch renders the actual computed mix rather than a hand picked hex. Caption it in solid white and set the chip on a solid ground fill with a thin white/14 border."
    },
    {
      "component": "Blend-surface caption band",
      "description": "A band whose readable surface is the genuine overlap of the two brand colours.",
      "prompt": "Overlap two wide flat rectangles of the two brand colours from opposite ends of a band (about 64% width each) with mix-blend-mode: screen in an isolated context, and set the caption in the dark ground colour inside the computed overlap region, where the added light is bright enough to carry dark ink. Use it for the offering that belongs to both halves of the business."
    },
    {
      "component": "Cue chips",
      "description": "Colour-of-the-light chips that key list rows to the lamp that is up.",
      "prompt": "Give each row of a schedule or cue list a small 16px flat square chip in the colour of the light that is on at that moment: white at 20 percent opacity for house light, the magenta gel for show cues, the cyan gel for room cues. No icons, no borders; the chip colour is the information."
    },
    {
      "component": "All-lamps-on white CTA",
      "description": "The booking action rendered as the rig at full: the only pure white surfaces on the page.",
      "prompt": "Reserve pure white for the action: white rectangular buttons with dark ground-colour text, a solid white flagship price card carrying both gel chips, and a full bleed white closing band with a dark button. Everything else stays on the dark ground, so at squint distance the brightest objects on the page are exactly the things you can act on."
    }
  ]
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
