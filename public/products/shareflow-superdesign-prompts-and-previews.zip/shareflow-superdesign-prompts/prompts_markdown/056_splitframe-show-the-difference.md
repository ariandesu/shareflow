# Splitframe — Show the Difference

**Category:** Style  
**Tags:** carousel, before-after, comparison-slider, image-comparison, drag-to-compare, split-image, slider, landing-page, hero, warm, sand, terracotta, editorial, inter, single-accent, desktop, ui-pattern, accessible, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/6d652e4a-86d2-45ec-97ea-8e15732391aa](https://p.superdesign.dev/draft/6d652e4a-86d2-45ec-97ea-8e15732391aa)  
**Local Standalone Preview:** `previews/splitframe-show-the-difference.html`

---

## Architectural & Aesthetic Breakdown
A warm sand/terracotta landing page for a draggable before/after image-comparison slider: a bold black 'Show the difference.' hero with a circular-grip comparison frame (warm dusk 'After' wiping over cool night 'Before'), a dark marquee, a 3-step how-it-works grid, a 2-up gallery of more sliders, a copy-the-prompt code block and a terracotta CTA. Inter, single terra accent on sand neutrals, sticky translucent nav, reflows to one column below lg.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A warm, editorial landing page for a before/after image-comparison slider component. The hero pairs a bold black serif-weight headline ('Show the difference.') and a stat row beside a draggable comparison frame that wipes a warm 'After' dusk render over a cool 'Before' night render via a circular center handle. Below: a dark uppercase marquee strip, a 3-step 'how it works' grid, a full-bleep two-card gallery of more comparison sliders, a copy-the-prompt code block, a 4-up features grid, a terracotta CTA band and a footer. Sticky translucent top nav; reflows from a 2-col hero to single column below lg.",
  "style": {
    "description": "Warm sand/terracotta editorial aesthetic in the Inter typeface, set on a cream paper canvas with a single terracotta (terra) accent and near-black 'ink' text. Heavy black headline weights (font-black) with very tight negative tracking, a subtle radial grain texture, soft layered ink-tinted shadows, fully rounded pills and large 20-28px rounded card/frame corners. The signature surface is the comparison frame: two stacked SVG 'scenes' (a warm dusk gradient vs a desaturated cool night gradient) split by a 2px light divider with a 56px circular grip carrying twin carets, plus pill 'Before' (light glass) and 'After' (terracotta) labels.",
    "prompt": "Design a warm editorial product landing page using the Inter font family (weights 300-900, antialiased) on a cream 'sand' canvas. Palette: sand #efe7d8 (page bg), sand-deep #e6dcc8, sand-soft #f6f1e7 (cards/light surfaces), terra #c4633f (primary accent), terra-deep #a84e2f (accent hover), ink #2b251d (near-black text), ink-soft #5c5346 (secondary text). Use a single terracotta accent against the sand neutrals and near-black ink; never introduce a second chromatic hue for UI. Headlines are font-black with letter-spacing -0.04em (tracking-tightest) and tight leading (~0.95). Apply a faint radial-dot 'grain' texture (radial-gradient rgba(43,37,29,0.025) 1px dots on a 4px grid) behind the hero. Rounding: pills/buttons rounded-full, cards rounded-2xl (16px), comparison frames rounded-[20px]/[22px]. Shadows are soft and ink-tinted (e.g. 0 30px 60px -24px rgba(43,37,29,0.4) on the hero frame, 0 20px 44px -28px on gallery cards). Hover states lift cards -translate-y-1 and shift the terra border to terra/40; primary CTA buttons darken terra -> terra-deep. Keep the whole page on a max-w-[1200px] container."
  },
  "layout_and_structure": {
    "description": "A full-width sticky 64px nav over a stacked single-page layout, all centered in a max-w-[1200px] ('container') column: HERO (2-col on lg, copy + comparison frame), a dark marquee strip, a 'How it works' 3-card grid, a 'Gallery' section (sand-deep band, 2-col cards of more comparison sliders), a 'The prompt' 2-col block (copy + dark code panel), a 4-up 'Features' grid on a sand-soft band, a terracotta CTA band, and a footer. The hero grid is lg:grid-cols-[0.95fr_1.05fr] and collapses to one column below lg; gallery and features grids collapse to single column on mobile.",
    "prompts": [
      {
        "part": "Sticky top nav",
        "prompt": "A full-width sticky header (sticky top-0, z-50) with a translucent sand background (bg-sand/85) + backdrop-blur-md and a 1px ink/10 bottom border. Inner row h-16, max-w-[1200px], px-6, items-center justify-between. Left: brand lock-up = a 32px (h-8 w-8) rounded-lg ink #2b251d tile holding a sand-colored 'columns' (two-column) glyph, beside the word 'Splitframe' at 17px font-extrabold tracking-tightest ink. Center (md+ only): nav links 'How it works / Gallery / Prompts / Features' at 14px font-medium ink-soft #5c5346 that darken to ink on hover, gap-8. Right: a 'Sign in' text link (ink-soft, sm+ only) and a 'Try a prompt' pill (bg-terra #c4633f, sand-soft text, rounded-full, px-5 py-2.5, font-semibold, shadow-sm) darkening to terra-deep #a84e2f on hover."
      },
      {
        "part": "Hero (copy + comparison frame)",
        "prompt": "A grain-textured section with two soft blurred color orbs (a terra/10 blob top-right, a sand-deep/60 blob bottom-left). Inner grid max-w-[1200px], px-6, py-20 to py-28, items-center, gap-14, lg:grid-cols-[0.95fr_1.05fr]. LEFT copy column: a rounded-full pill badge (ink/15 border, sand-soft/70 fill, 12px uppercase tracking-[0.14em] ink-soft) reading 'Prompt library . UI patterns' with a leading terra sparkle; an h1 'Show the difference.' at clamp(2.7rem,6vw,4.6rem) font-black leading-[0.95] tracking-tightest, where the word 'difference.' sits above a terra/25 highlighter underline bar; a 17px ink-soft lead paragraph (max-w-md) describing the draggable slider; a button row with a primary ink pill 'Drag to compare' (bg-ink, sand-soft text, trailing left-right-arrows icon that nudges on hover) and a secondary outlined 'Copy the prompt' (ink/20 border); and a stat row of three figures separated by 1px ink/15 dividers: '2px / clean divider', '0 deps / pure pointer events', 'A11y / keyboard ready' (figure at 22px font-extrabold ink over a 13px ink-soft caption). RIGHT: the hero comparison frame (see component)."
      },
      {
        "part": "Dark marquee strip",
        "prompt": "A full-width band, border-y ink/10, bg-ink #2b251d, sand-soft text. Inner flex-wrap row max-w-[1200px], px-6, py-5, justify-center, gap-x-10 gap-y-3, of 12px font-semibold uppercase tracking-[0.18em] labels each with a leading terra icon: 'Photo retouch' (image-square), 'Restoration' (paint-roller), 'UI redesign' (layout), '3D renders' (cube), 'AI upscale' (scan), separated by dimmed '/' slashes (opacity-30)."
      },
      {
        "part": "How it works (3 steps)",
        "prompt": "A max-w-[1200px] section, px-6, py-20 to py-24. Header block (max-w-2xl): a 12px font-bold uppercase tracking-[0.16em] terra eyebrow 'How it works', an h2 'Two images. One handle. Zero fuss.' at clamp(1.9rem,4vw,2.9rem) font-black tracking-tightest, and a 16px ink-soft lead. Below, a 3-col grid (gap-6, md:grid-cols-3) of step cards: each rounded-2xl, 1px ink/10 border, bg-sand-soft, p-7, with a hover lift (-translate-y-1, border->terra/40, soft shadow); inside, an 11x11 rounded-xl terra/12 tile holding a 22px terra icon (stack / scissors / hand-pointing), an h3 '01 . Stack' / '02 . Clip' / '03 . Drag' at 18px font-extrabold, and a 14px ink-soft body."
      },
      {
        "part": "Gallery (more comparison sliders)",
        "prompt": "A band with bg-sand-deep/40. Inner max-w-[1200px], px-6, py-20 to py-24. A header row (flex-col -> sm:flex-row, items-end justify-between): a terra eyebrow 'Gallery' + an h2 'Drag any of them.' on the left, a 15px ink-soft note on the right. Below, a 2-col grid (gap-7, lg:grid-cols-2) of figure cards, each rounded-[20px], 1px ink/10 border, bg-sand-soft, soft shadow, overflow-hidden: a 16:10 comparison frame (same component, different SVG scenes + labels: 'Raw'/'Retouched' for a portrait-retouch card, 'v1'/'Redesign' for a dashboard-redesign card) above a figcaption row (px-6 py-5, justify-between) with a 16px font-extrabold title + 13px ink-soft sub on the left and a faint ink/30 arrows-out icon on the right."
      },
      {
        "part": "The prompt (copy block)",
        "prompt": "A max-w-[1200px] section, px-6, py-20 to py-24, grid items-center gap-12 lg:grid-cols-2. LEFT: a terra eyebrow 'The prompt', an h2 'Copy it. Generate your own.' (clamp font-black tracking-tightest), a 16px ink-soft lead, and a 3-item checklist (space-y-3, 15px) where each row has a terra check-circle icon and an ink-soft line with a bold ink lead phrase ('Draggable divider', 'Before / after labels', 'Touch, mouse, keyboard'). RIGHT: a dark code panel = rounded-2xl, 1px ink/12 border, bg-ink, deep shadow; a top bar (border-b white/10, px-5 py-3.5) with a 'prompt.txt' label (12px uppercase tracking, sand-deep, leading terra terminal icon) and a 'Copy' button (white/10 pill, copy icon); a <pre> body (px-5 py-5, 13.5px leading-relaxed, sand-soft) of the natural-language prompt with the verb 'Build' in terra and quoted nouns ('two images', 'vertical divider', '\"Before\"', '\"After\"') tinted warm sand #e7c9a3."
      },
      {
        "part": "Features (4-up)",
        "prompt": "A band border-t ink/10, bg-sand-soft. Inner max-w-[1200px], px-6, py-20 to py-24, grid gap-10 md:grid-cols-4. Col 1 (md:col-span-1): an h2 'Built to feel good in hand.' at clamp(1.7rem,3vw,2.3rem) font-black tracking-tightest. Cols 2-4 (md:col-span-3): a sm:grid-cols-2 grid (gap-x-10 gap-y-8) of four feature items, each = a 24px terra icon (lightning / device-mobile / keyboard / palette), a 16px font-extrabold title ('Snappy pointer tracking', 'Responsive frames', 'Keyboard nudge', 'Themeable'), and a 14px ink-soft body."
      },
      {
        "part": "CTA band + footer",
        "prompt": "A full-width terracotta band: bg-terra #c4633f, sand-soft text, a centered column (max-w-[1200px], px-6, py-20, items-center, text-center, gap-6): an h2 'Stop describing the change. Show it.' at clamp(2rem,4.5vw,3.2rem) font-black leading-[1.02] tracking-tightest, a 16px sand-soft/85 lead (max-w-md), and a button row of a solid sand-soft 'Open in canvas' pill (ink text, trailing up-right-arrow, hover->white) + an outlined 'Browse the gallery' pill (sand-soft/40 border). Footer: border-t ink/10, bg-sand, a max-w-[1200px] row (px-6 py-9, flex-col -> sm:flex-row, items-center justify-between, gap-5) with the Splitframe brand lock-up, a 13px ink-soft tagline 'A prompt-library UI pattern . before / after comparison slider', and 3 ink-soft social icons (github / x / book-open) that darken to ink on hover."
      }
    ]
  },
  "special_ui_components": [
    "Before/after comparison slider: a relative overflow-hidden frame stacking two full-bleed layers (a base 'after' layer + a top 'before' layer clipped to a tracking width), a 2px #f6f1e7 vertical divider, and a 56px circular #f6f1e7 grip (ew-resize, terra twin-caret glyphs, soft 0 8px 24px ink shadow). Pointer/touch drag maps x-position to a 0-100% clip width; the handle is focusable (role=slider, tabindex 0) and Arrow Left/Right nudge the divider 2% for keyboard accessibility; an optional data-start sets the initial split.",
    "Pinned 'Before'/'After' pill labels: uppercase 11px tracking-[0.14em] pills with backdrop-blur, the Before label light glass (sand-soft/85 fill, ink text, pinned left) and the After label terracotta (terra/92 fill, sand-soft text, pinned right).",
    "SVG 'scene' renders inside each frame: a warm dusk gradient (linear #f0c9a0 -> #dd9a6f -> #9c5a3f with a #fbe7c6 radial sun + layered mountain paths) for 'After' vs a desaturated cool night gradient (#cdd9d0 -> #9aa39a -> #5d645d with a grey overlay + cool mountains) for 'Before', preserveAspectRatio slice.",
    "Sticky translucent (bg-sand/85 + backdrop-blur-md) full-width top nav with an ink logo tile and a terra 'Try a prompt' pill.",
    "Grain-textured hero with two blurred color orbs (terra/10 + sand-deep/60) and a highlighter underline bar (terra/25) under a single headline word.",
    "Dark uppercase marquee strip (bg-ink, terra leading icons, dimmed slash separators).",
    "Lift-on-hover bordered cards (-translate-y-1, border -> terra/40, soft ink-tinted shadow) for the 3 'how it works' steps.",
    "Dark code/terminal panel (bg-ink, 'prompt.txt' bar + Copy button) with syntax-tinted text (terra verb, warm-sand #e7c9a3 quoted nouns).",
    "Terracotta full-bleed CTA band with paired solid + outlined pill buttons."
  ],
  "special_notes": "Single-accent system: terracotta 'terra' #c4633f is the only chromatic color; everything else is the warm sand neutral scale (sand #efe7d8 / sand-deep #e6dcc8 / sand-soft #f6f1e7) plus near-black 'ink' #2b251d / 'ink-soft' #5c5346, so the accent always reads as the action. ONE typeface: Inter (weights 300-900) via Google Fonts; headlines use font-black with letter-spacing -0.04em (tracking-tightest). All hex values are exact and should be preserved, including the comparison-frame SVG gradient stops (dusk #f0c9a0/#dd9a6f/#9c5a3f, sun #fbe7c6; night #cdd9d0/#9aa39a/#5d645d) and the code-block syntax tint #e7c9a3. No em-dashes in any copy; the before/after relationship is shown via the draggable slider, not described. Icons are Iconify Phosphor (ph:*) glyphs. The whole page is centered in a max-w-[1200px] container and reflows from the 2-col hero to a single column below lg."
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
