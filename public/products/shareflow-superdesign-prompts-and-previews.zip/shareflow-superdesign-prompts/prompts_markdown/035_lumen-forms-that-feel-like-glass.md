# Lumen — Forms that feel like glass

**Category:** Animation  
**Tags:** form, glassmorphism, dark-mode, signup, login, aurora, frosted-glass, landing-page, tailwind  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/dd22cfa2-c01a-463b-829e-b2d61d4003f4](https://p.superdesign.dev/draft/dd22cfa2-c01a-463b-829e-b2d61d4003f4)  
**Local Standalone Preview:** `previews/lumen-forms-that-feel-like-glass.html`

---

## Architectural & Aesthetic Breakdown
A dark glassmorphism form landing page: a frosted, focus-aware account form floating over drifting aqua-and-magenta aurora orbs, with gradient CTAs, a feature grid, and login/checkout/error form showcases.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A dark glassmorphism marketing-and-form landing page (\"Lumen \u2014 Forms that feel like glass\") on a near-black #0b0f14 ground. A frosted, focus-aware account form floats in the hero over drifting aurora orbs (aqua #2dd4bf + magenta #e879f9), paired with a left-side value prop. Below: a 6-card feature grid, a 3-up form showcase (login / card checkout / feedback-error states), a prompt-library split, a centered pricing CTA band, and a slim footer. Frosted blur, a faint masked grid, gradient text, and a teal\u2192sky\u2192magenta gradient CTA carry the system end to end.",
  "style": {
    "description": "Premium dark glassmorphism: near-black ink ground, frosted translucent surfaces with backdrop-blur and a 1px white hairline, neon aqua-to-magenta aurora gradients, and a focus-glow accent system. Display headings in Space Grotesk, body in Inter. No hard shadows in the diffuse sense \u2014 light is carried by blur, soft inner top highlights, and colored glows.",
    "prompt": "Design a dark glassmorphism landing page. Background: solid ink #0b0f14, body text #e7ecf2. Two brand accents drive everything: aqua #2dd4bf (with #5eead4 light and #7dd3fc sky as a tertiary) and magenta #e879f9 (with #f5d0fe light). Typography: display/headings use 'Space Grotesk' 600-700 with tight tracking; body/UI uses 'Inter' 400-600; antialiased, optimizeLegibility. Surfaces are frosted glass \u2014 translucent white fills (linear-gradient 150deg from rgba(255,255,255,0.10) to 0.02), backdrop-filter blur(28px) saturate(140%), 1px border rgba(255,255,255,0.14), and a layered shadow '0 30px 80px -30px rgba(0,0,0,0.85), inset 0 1px 0 rgba(255,255,255,0.18)'; a lighter 'glass-soft' variant uses rgba(255,255,255,0.045) fill, blur(16px), 1px rgba(255,255,255,0.08) border. Hairline dividers are rgba(255,255,255,0.08). Behind glass, place blurred aurora orbs (radial-gradient aqua and magenta, border-radius 9999px, filter blur(34-50px)) that slowly drift via keyframe float (17-20s ease-in-out). Headlines use a gradient-clip text 'linear-gradient(100deg,#2dd4bf 0%,#7dd3fc 38%,#e879f9 100%)' on the emphasized word. Primary CTA is a pill/rounded button with 'linear-gradient(100deg,#2dd4bf,#34d3c4 50%,#e879f9 140%)', dark ink text #04110f, glow shadow '0 12px 40px -12px rgba(45,212,191,0.6)' + inset top highlight, lifting -2px on hover. Eyebrow tags are aqua-tinted pills: bg rgba(45,212,191,0.10), 1px rgba(45,212,191,0.28) border, #5eead4 text. Keep generous whitespace, rounded-2xl/3xl radii, and a calm, high-end feel."
  },
  "layout_and_structure": {
    "description": "Single-column scrolling page on a max-w-7xl (1280px) centered container with px-6/lg:px-8 gutters. Fixed translucent nav, then a 2-column hero (copy left, glass form right) over a masked grid + radial wash, a trust logo strip, a 3-col feature grid, a 3-col showcase, a 5/7 prompt-library split, a centered pricing band, and a footer. Sections separated by top hairline borders and ~py-24/28 rhythm. Everything reflows to a single column under lg; mobile centers the hero copy and stacks the form below.",
    "prompts": [
      {
        "part": "Sticky nav",
        "prompt": "Fixed top nav, full-width, z-50, translucent bg rgba(11,15,20,0.62) with backdrop-blur(18px) saturate(140%) and a bottom hairline. Inside a max-w-7xl row, h-16: left = brand lockup (an 8x8 rounded-lg chip filled 'linear-gradient(135deg,#2dd4bf,#e879f9)' holding a ph:diamonds-four-fill ink icon, plus 'Lumen' in Space Grotesk 600); center (md+ only) = nav links Features / Showcase / Prompt Library / Pricing in white/65 with hover:white; right = a 'Sign in' text link (sm+) and a gradient 'Start free' pill CTA with a ph:arrow-right-bold."
      },
      {
        "part": "Hero",
        "prompt": "Full-bleed hero, pt-28/lg:pt-36, overflow-hidden. Background layers: a deep radial wash (aqua top-center + magenta bottom-right, both fading to transparent) and a faint grid (1px white/0.035 lines on 56px cells) radially masked so it fades at the edges. Content is a 2-col grid (lg:grid-cols-2). LEFT: an aqua eyebrow tag 'Form Design, generated from a prompt' with ph:sparkle-fill; an h1 in Space Grotesk ~64px/700 'Forms that feel like glass.' with 'glass.' in gradient-clip text; a white/65 lead paragraph (max-w-md); a button row = gradient CTA 'Generate a form' (ph:magic-wand-fill) + a glass-soft pill 'See the canvas' (ph:play-circle-fill); and two check rows (ph:check-circle-fill in aqua) 'Tailwind export' / 'WCAG focus states'. On lg the copy is left-aligned; below lg it centers."
      },
      {
        "part": "Hero glass form",
        "prompt": "RIGHT side of hero: a frosted glass form card, max-w-[420px], rounded-3xl, p-7/8, z-10, with three blurred aurora orbs bleeding behind it (a 280px aqua top-left, a 300px magenta bottom-right, a 160px aqua mid-right at lower opacity), each slowly drifting. Card header: 'Create account' (Space Grotesk 600, text-2xl) plus a glass-soft 'AI draft' chip (aqua text, ph:sparkle-fill). Subtext white/55 'Live preview generated from your prompt.' Fields use the dark glass field style (bg rgba(9,13,18,0.55), 1px white/0.10 border): an Email input with a ph:envelope-simple leading icon; a Password input with a ph:lock-simple leading icon, a ph:eye trailing toggle, and a 4-segment strength meter (two aqua, one magenta, one white/12) labeled 'Good'; a custom checkbox row (a gradient-filled rounded check w/ ph:check-bold) 'Email me product tips, no spam.' Full-width gradient CTA 'Create account'. An 'or continue with' hairline divider, then a 2-col grid of glass-soft social buttons (Google logos:google-icon, GitHub ph:github-logo-fill)."
      },
      {
        "part": "Trust strip",
        "prompt": "Below the hero grid, a top-hairline strip: a centered uppercase white/65 micro-label 'Trusted by design teams shipping fast' (tracking-[0.2em]), then a wrapping row of 5 muted wordmark logos (Northwind, Orbit, Halcyon, Voltage, Forma), each a Space Grotesk label with a leading phosphor icon (ph:orange-slice-fill, ph:planet-fill, ph:hexagon-fill, ph:lightning-fill, ph:cube-fill)."
      },
      {
        "part": "Features grid",
        "prompt": "Section 'Why Lumen' with a faint aqua radial wash top-left. Eyebrow tag (ph:stack-fill), an h2 'Every detail a great form needs, by default.' with 'by default.' in gradient text, and a white/60 lead. Then a responsive grid (1/sm:2/lg:3) of 6 glass-soft cards, each: an 11x11 rounded-xl tinted icon chip (alternating aqua / magenta / sky tints with matching 0.28 borders), a Space Grotesk lg title, and a white/55 description. Cards: Focus-aware fields (ph:cursor-click-fill), Validation built in (ph:shield-check-fill), Responsive out of the box (ph:devices-fill), Clean Tailwind export (ph:code-fill), Infinite canvas (ph:infinity-fill), Theme tokens (ph:palette-fill). Cards brighten their border on hover."
      },
      {
        "part": "Showcase",
        "prompt": "Full-bleed 'One prompt, many forms' section with a vertical aqua gradient wash and two faint corner orbs. Centered header: eyebrow tag (ph:squares-four-fill), h2 'From sign-in to checkout, all glass.' (gradient 'all glass.'), white/60 lead. Then a 3-col grid (lg) of full 'glass' (heavier) cards, each prefaced by a tiny terminal-style prompt label (ph:terminal-window-fill): (1) 'a minimal login' \u2014 Welcome back, Email + Password fields, gradient 'Sign in'. (2) 'a card checkout' \u2014 Payment, a Card-number field shown in the FOCUSED state (aqua border + aqua glow ring, ph:credit-card-fill trailing icon), Expiry + CVC in a 2-col row, gradient 'Pay $29.00'. (3) 'a feedback form' \u2014 Tell us more, an Email field in the ERROR state (red #f87171 border + red glow + a ph:warning-circle-fill 'Enter a valid email' message in #fca5a5), a Message textarea, and a glass-soft 'Send feedback'. Use these as the canonical focus / error state references."
      },
      {
        "part": "Prompt library",
        "prompt": "Top-hairline section, a 12-col grid: LEFT (col-span-5) = eyebrow tag (ph:books-fill), h2 'Start from a prompt that already works.' (gradient 'already works.'), white/60 lead, and an aqua 'Explore the library' link with a ph:arrow-right-bold that nudges right on hover. RIGHT (col-span-7) = a 2-col grid of 4 glass-soft prompt cards, each with a leading phosphor icon (ph:sign-in-fill, ph:credit-card-fill, ph:user-circle-plus-fill, ph:gear-fill) + a 'copy' tag top-right, and a quoted example form prompt as the body; cards tint their border aqua or magenta on hover."
      },
      {
        "part": "Pricing CTA band",
        "prompt": "Full-bleed centered band (max-w-4xl) over a magenta-bottom + aqua-top radial wash. A big h2 'Ship the form, not the busywork.' (Space Grotesk up to 5xl/700, 'not the busywork.' in gradient text), a white/60 supporting line, a centered button row = gradient pill 'Start designing free' (ph:arrow-right-bold) + glass-soft pill 'Talk to us', and a white/65 reassurance line 'Free forever for solo builders. Pro from $19/mo.'"
      },
      {
        "part": "Footer",
        "prompt": "Top-hairline footer, max-w-7xl, py-12: a row (stacks on mobile, justified on md) with the Lumen brand lockup, a set of text links (Features / Library / Pricing / Docs in white/65 hover:white), and 3 social icon links (ph:x-logo-fill, ph:github-logo-fill, ph:discord-logo-fill). Below, a small white/65 line '\u00a9 2026 Lumen Design. Forms that feel like glass.'"
      }
    ]
  },
  "special_ui_components": [
    "Frosted glass card: translucent white gradient fill + backdrop-blur(28px) saturate(140%) + 1px rgba(255,255,255,0.14) border + layered drop shadow and inset top highlight; a lighter 'glass-soft' variant for secondary surfaces and buttons.",
    "Focus-aware form field: dark glass fill rgba(9,13,18,0.55), 1px white/0.10 border, placeholder white/62; on focus the border turns aqua rgba(45,212,191,0.85) with a 3px aqua ring + 28px aqua glow (a magenta variant uses #e879f9 instead). Card-checkout field demonstrates the focused state; feedback field demonstrates a red error state.",
    "Drifting aurora orbs: large blurred radial-gradient circles (aqua and magenta) animated with two slow keyframe drifts (auroraDrift 17s / auroraDriftAlt 20s), placed behind glass surfaces to bleed colored light through the blur.",
    "Gradient CTA: pill/rounded button filled 'linear-gradient(100deg,#2dd4bf,#34d3c4,#e879f9)' with dark ink text, aqua glow shadow + inset top highlight, lifting on hover.",
    "Gradient-clip headline text: teal\u2192sky\u2192magenta linear-gradient clipped to the emphasized word in each heading.",
    "Password strength meter: 4 equal segment bars (filled aqua, aqua, magenta, then an empty white/12) with a 'Good' label.",
    "Custom gradient checkbox: an 18px rounded square filled with the aqua gradient holding a ph:check-bold tick.",
    "Aqua eyebrow tag pill: rgba(45,212,191,0.10) bg, rgba(45,212,191,0.28) border, #5eead4 text, with a leading phosphor icon, used to label every section.",
    "Masked background grid: 1px white/0.035 grid on 56px cells, radial-masked so it fades out toward the edges, used as hero texture.",
    "Phosphor (Iconify ph:*) icon set throughout, plus logos:google-icon for the social button."
  ],
  "special_notes": "Built with the Tailwind CDN; fonts loaded from Google Fonts (Inter + Space Grotesk); icons via Iconify (phosphor 'ph:*' family + 'logos:google-icon'). Tailwind theme extends colors ink:#0b0f14, aqua:#2dd4bf, magenta:#e879f9 and font families sans:Inter / display:'Space Grotesk'. The glassmorphism depends on backdrop-filter, so render on a non-white, textured ground (the aurora orbs + grid) for the frost to read. Honor reduced-motion by allowing the orb animations to pause. Form is non-submitting (onsubmit return false) \u2014 it's a design preview. Maintain WCAG-grade focus visibility (the 3px ring is intentional, not decorative). Reflows cleanly from 390px to 1440px: hero copy centers and the form stacks under lg, grids collapse to a single column."
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
