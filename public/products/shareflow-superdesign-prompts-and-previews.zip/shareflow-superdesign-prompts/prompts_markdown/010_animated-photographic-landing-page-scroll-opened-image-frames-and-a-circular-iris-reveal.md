# Animated Photographic Landing Page: Scroll-Opened Image Frames and a Circular Iris Reveal

**Category:** Animation  
**Tags:** landing, landing-page, animated, animation, scroll-animation, scroll-pinned, sticky, parallax, clip-path, iris, reveal, photographic, travel, hotel, hospitality, retreat, resort, editorial, warm, sand, navy, coral, archivo, ibm-plex-mono, dark-mode, desktop, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/beaac976-b221-4326-a6c0-8a3a8b3993c9](https://p.superdesign.dev/draft/beaac976-b221-4326-a6c0-8a3a8b3993c9)  
**Local Standalone Preview:** `previews/animated-photographic-landing-page-scroll-opened-image-frames-and-a-circular-iris-reveal.html`

---

## Architectural & Aesthetic Breakdown
An animated, photographic LANDING PAGE for a stay, retreat, hotel or travel brand, in a warm desert register: sand #F0E5D4, deep navy #0B2030 and coral #C64A32, with Archivo at width 74 percent and IBM Plex Mono at +0.2em. Four sections pin as you scroll and the photographs are the motion. A full-bleed hero parallaxes against the type. A framed image OPENS from a small inset rectangle to full bleed as you scroll, its caption carrying a scrim so it stays legible once it crosses onto the picture. A third image is revealed through an expanding CIRCULAR IRIS while the headline over it sits in mix-blend-mode difference. A nightly log advances row by row beside a drawn star field that slowly rotates. Every headline splits into per-word spans and roughly 185 elements move independently. Reusable for any hotel, lodge, retreat, tour, restaurant or property brand whose photography is the product.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A long scroll-choreographed LANDING page for a destination stay (built here as 'Ninth Meridian', a dark-sky desert observatory with rooms). Warm desert register: deep navy #0B2030 and #07141F for the dark stages, sand #F0E5D4 and cream #F5EDE2 for the light ones, ink #33291E, and coral #C64A32 with a soft #E2705A as the only chroma. Archivo variable set at font-stretch 74 percent and weight 800 for display, with its ITALIC 300 used for one word per headline; IBM Plex Mono at 11px and +0.2em for all furniture. A fixed film-grain plate at 5 percent sits over everything. FOUR pinned stages, and in three of them a PHOTOGRAPH is the thing that moves: (1) a hero where a full-bleed landscape parallaxes on translateY and scale against a type block that lifts and fades, with a two-stop veil keeping the copy legible; (2) a frame stage where a second photograph opens from clip-path inset(34% 30% round 4px) to inset(0) as the stage scrubs, revealing itself while a large coral numeral and a captioned scrim fade up; (3) an iris stage where a third photograph is revealed through clip-path circle() expanding from 0 to 78 percent at the centre, with the headline above it in mix-blend-mode difference so it inverts against whatever the picture is doing, fading out as the circle completes; (4) a log stage where five timestamped rows light cumulatively beside a drawn star field of 220 points on a phyllotaxis spiral that slowly rotates and twinkles. Then normal bands: a three-column explainer, a rates table of ruled rows with mono figures in coral, and an FAQ. Every headline, lede and caption splits into per-word spans on a 38ms stagger and every row, cell and strap carries its own delay, so roughly 185 elements move independently.",
  "style": {
    "description": "Warm desert photographic. Two grounds, one coral accent, and photography carrying the emotion while type stays disciplined. The display face runs narrow and heavy with a single italic light word per headline as the only flourish. Furniture is wide-tracked mono. No radii beyond a 4px softening on the opening frame, no shadows, no gradient decoration except the functional veils that keep copy readable over pictures.",
    "prompt": "Palette: deep navy #0B2030 with #07141F for the deepest stage, sand #F0E5D4 and #E6D8C3, cream #F5EDE2, ink #33291E, coral #C64A32 with #A83D28 pressed and #E2705A soft. Muted text is rgba(51,41,30,.58) on light and rgba(245,237,226,.55) on dark. Typography: Archivo loaded as a variable font on ital, wdth AND wght; set every display line at weight 800, font-stretch 74%, letter-spacing -.025em to -.035em, and set exactly ONE word per headline in the italic at weight 300 in soft coral. IBM Plex Mono 400 at 11px, letter-spacing .2em, uppercase, for every strap, caption, timestamp and price. Add a fixed grain overlay at opacity .05 with mix-blend-mode overlay from an inline SVG feTurbulence data URI. Ease everything with cubic-bezier(0.16,1,0.3,1) at 1.2s. Photography is warm, natural-light, fine-grained and unpeopled; never use stock-looking imagery with faces or visible signage."
  },
  "layout_and_structure": {
    "description": "Four tall pinned stages (300svh to 360svh), each a position:sticky inner at top:0, height:100svh, overflow:hidden, then two normal bands. Every animated quantity is a CSS custom property on :root written by ONE rAF-throttled scroll handler.",
    "prompts": [
      {
        "part": "Parallax photographic hero",
        "prompt": "A 300svh stage on deep navy. The photograph is absolutely positioned with inset -8% top and bottom so it has room to travel, transformed by translateY(progress * -0.22 * 460px) and scale(1.06 to 1.12), object-fit cover. Over it a three-stop vertical veil (55% at the top, 12% at a third, 72% at the base) so both the nav and the bottom copy stay legible without flattening the picture. The type block lifts 60px and fades out over the stage. Set the wordmark with one italic light word in soft coral. SIZE THE WORDMARK FROM ITS CHARACTER COUNT: font-size: min(var(--display), calc(90vw / (chars * .48))) with white-space:nowrap, because a bare vw fits only the word the reference happened to use and overflow:hidden on the pin will hide the clipping from a page-level overflow check."
      },
      {
        "part": "The opening frame",
        "prompt": "A 360svh stage. A photograph fills the pin but is clipped to clip-path: inset(calc(34% - p * 34%) calc(30% - p * 30%) round 4px), so it begins as a small centred rectangle and opens to full bleed as the stage scrubs. A large coral numeral sits top-right and rises from 25 to 100 percent opacity. The caption sits bottom-left and MUST carry its own gradient scrim (a bottom-anchored linear-gradient to 92 percent of the dark ground, at 56 percent height, fading in with the image), because once the frame opens the caption is sitting on the photograph and the ground colour is no longer behind it."
      },
      {
        "part": "The circular iris",
        "prompt": "A 320svh stage on the sand ground. A photograph is clipped to clip-path: circle(calc(p * 78%) at 50% 50%) so it grows from nothing at the centre. The headline sits ABOVE it in mix-blend-mode: difference with colour #fff, so it inverts itself against both the sand ground and the picture as the circle passes under it, and fades out as the reveal completes. A mono caption pair fades in at the bottom only after the circle is half open. Under reduced motion the clip-path must be removed and the headline returned to normal blending, or it will be invisible."
      },
      {
        "part": "The log and the star field",
        "prompt": "A 340svh stage on deep navy, two columns. Left: a headline with one italic coral word, then five ruled rows laid out as a mono timestamp, a bold label and a muted note, at 0.3 opacity, lighting cumulatively as floor(p * 5) advances. Right: a square canvas drawing 220 stars on a phyllotaxis spiral (angle i * 2.399, radius sqrt(i/220)), each twinkling on its own sine, the whole field rotating at 0.035 radians per second, with two faint concentric circles as the horizon rings and every 23rd star in soft coral. Only touch the DOM when the row index changes."
      },
      {
        "part": "Per-atom motion budget",
        "prompt": "Split every headline, lede, frame caption and column paragraph into per-word inline-block spans rising 0.4em on a 38ms incremental delay. Then give every explainer column, column title, table row, table cell, log label, log timestamp, log note, FAQ summary, hero strap item, iris caption, button, nav link and footer line its own data-rev attribute with a --d delay of 40 to 90ms times its index, revealed by one IntersectionObserver at threshold 0.12. Target roughly 185 independently moving elements."
      }
    ]
  },
  "special_ui_components": [
    "Photograph that opens from an inset rectangle to full bleed on scroll, with a caption scrim that arrives with it",
    "Circular iris reveal with the headline over it in mix-blend-mode difference",
    "Parallax hero photograph travelling against a fading type block",
    "Rotating phyllotaxis star field drawn on canvas beside a log that advances row by row",
    "Fixed film-grain plate from an inline SVG feTurbulence data URI"
  ],
  "implementation_notes": "Single self-contained HTML file. One Google Fonts link (Archivo variable on ital/wdth/wght, IBM Plex Mono) is the only external request. Photographs are base64 WebP data URIs, not linked files, so the page stays self-contained: generate at 2K, downscale to about 2000px for the hero and 1100px for the portraits, encode as WebP, and expect roughly a 240KB total base64 payload for three images. VERIFY THE IMAGES ACTUALLY DECODE by checking naturalWidth !== 0 in a headless pass; a malformed data URI still renders a valid-looking page and passes every layout check while showing nothing. Drive all motion from CSS custom properties written by ONE scroll listener throttled through requestAnimationFrame; read stage progress as -rect.top / (rect.height - innerHeight) clamped 0..1. Under prefers-reduced-motion: flatten .stage heights, make pins static, remove BOTH clip-paths, return the iris headline to normal blend mode, and force all word spans and data-rev elements visible."
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
