# Animated Scroll-Printed Product Page: Warm Cream and Red Editorial With a Horizontal Card Rail

**Category:** Animation  
**Tags:** landing, landing-page, animated, animation, scroll-animation, scroll-pinned, sticky, horizontal-scroll, card-rail, clip-path, wipe, editorial, print, warm, cream, red, terracotta, anton, martian-mono, light-mode, ecommerce, product, catalogue, shop, artisan, craft, food, garden, desktop, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/5b4306a0-f3b2-4b33-92be-06a8154e6636](https://p.superdesign.dev/draft/5b4306a0-f3b2-4b33-92be-06a8154e6636)  
**Local Standalone Preview:** `previews/animated-scroll-printed-product-page-warm-cream-and-red-editorial-with-a-horizontal-card-rail.html`

---

## Architectural & Aesthetic Breakdown
An animated, scroll-driven LANDING or PRODUCT page in a warm print register: cream #e7e2d8, ink #171717 and one hot red #ef493c, with Anton set huge and Martian Mono carrying every label at +0.18em. Five sections pin as you scroll. A poster hero whose type lifts, shrinks and fades on three separate variables. A manifesto line that fills from grey to ink through a bottom-up clip-path wipe. A horizontal rail of product cards that travels sideways as you scroll down. A pinned stage where the product's paper artifact is PRINTED in front of you, filling in its lot number, its test result and its dates before a dashed perforation opens across it. A parallax plate whose chapters swap underneath a headline. Every headline splits into per-word spans and roughly 200 elements move independently. Driven entirely by CSS custom properties written from one requestAnimationFrame-throttled scroll handler, with no animation library. Reusable for any catalogue, shop, maker, food, garden or artisan brand that ships a physical thing.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A long scroll-choreographed LANDING page for a catalogue business (built here as 'Fallow Row', an heirloom seed house) whose thread runs from a variety to a printed packet. Warm print register throughout: cream #e7e2d8 ground, ink #171717, one hot red #ef493c, a dark loam #241a12 for the two dark stages, Anton for all display, Inter for body, Martian Mono at 10.5px and +0.18em for every label. FIVE pinned stages, all driven by CSS custom properties: (1) a hero on the dark ground over a generated field of drifting tilled-soil strokes, with a two-line poster lockup whose translateY, scale and opacity are three SEPARATE variables so the type lifts, shrinks and fades on independent curves; (2) a manifesto whose single large sentence sits in 34-percent ink and is filled to full ink from the bottom up by clip-path: inset(calc(100% - var(--wipe)) 0 0), while the whole line scales very slightly; (3) a horizontal rail of six product cards that translates sideways by exactly its own overflow width as the stage scrubs, with a progress meter beneath it, so scrolling down walks along the row; (4) the artifact stage, where a paper packet fades and scales up, fills in its lot number, germination result and sowing window as the phase index advances, lights four cues one at a time, prints a live status line, and finally opens a dashed perforation across itself; (5) a season band whose generated contour plate parallaxes on translateY and scale while three chapters swap underneath the headline. After the pins: a ruled price table, an FAQ of native details rows, and a dark footer. Every headline, lede and statement is split into per-word spans rising on a 38ms stagger, and every card, table row, cue, chapter, price and footer line carries its own staggered transform, so about 200 elements move independently.",
  "style": {
    "description": "Warm print editorial. Three committed colours plus one dark ground for contrast stages, heavy condensed display type against wide-tracked mono furniture, 1.5px ink borders and zero radii, and flat generated illustration instead of photography. The red is rationed to marks: prices, meters, the active cue border, the printed values on the artifact, and one word of the wordmark.",
    "prompt": "Palette: cream #e7e2d8 ground, ink #171717, hot red #ef493c, deep red #b92725, off-white #fffdf8 for paper, dark loam #241a12 for the two dark stages. Hairlines rgba(23,23,23,.16) and .08; muted text rgba(23,23,23,.56). Typography: Anton for every display line, uppercase, letter-spacing -.02em to -.045em, line-height .86; Inter 400 to 700 for body; Martian Mono 400 at 10.5px with letter-spacing .18em uppercase for every label, caption, price, lot number and status line. Radii 0 everywhere. Borders are 1.5px solid ink on paper elements and 1px hairlines elsewhere. No shadows, no gradients as decoration, no photography, no icon fonts. Ease with cubic-bezier(.22,1,.36,1); reserve cubic-bezier(.65,0,.35,1) for the cinematic stage transitions. Ration red to marks only: never a red ground, never red body copy."
  },
  "layout_and_structure": {
    "description": "Five tall pinned stages (260svh to 420svh) each containing a position:sticky inner at top:0, height:100svh, overflow:hidden, then three normal bands. All motion is expressed as CSS custom properties on :root, written by ONE scroll handler; the CSS never knows about JavaScript beyond the variable values.",
    "prompts": [
      {
        "part": "Poster hero on three variables",
        "prompt": "A 280svh stage, sticky inner on the dark loam ground, with a full-bleed canvas drawing a grid of short red strokes that drift on sines of time and index, at 5 to 19 percent alpha, like a tilled bed seen from above. Centre a two-line lockup: a smaller uppercase line above, and the brand name below in red at poster scale. Drive it with THREE independent custom properties, not one: --hero-type-y from 0 to -90px, --hero-type-scale from 1 to 0.74, --hero-type-alpha from 1 to 0. Pin mono metadata across the bottom, fading on page progress. SIZE EACH POSTER LINE FROM ITS OWN CHARACTER COUNT: font-size: min(<the vw clamp>, calc(92vw / (chars * .44))) for Anton, with white-space:nowrap. A bare vw value fits whatever word the reference used and silently wraps or clips anything longer; because the pin is overflow:hidden, a document-level overflow test will report clean while the lockup is visibly broken. Check each line's scrollWidth against its clientWidth instead."
      },
      {
        "part": "Clip-wipe manifesto",
        "prompt": "A 260svh stage on the cream ground holding ONE sentence at clamp(34px,5.6vw,78px) over 16ch, set in 34-percent ink. Overlay an absolutely positioned duplicate of the same sentence in full ink, clipped with clip-path: inset(calc(100% - var(--manifesto-wipe)) 0 0), and drive --manifesto-wipe from 0% to 100% across the stage so the sentence fills from the bottom up. Scale the whole line from 1 to 1.05 on a separate variable. The duplicate must be an exact copy in the same box or the fill will not register; verify its bounding rect matches the base to 0px on all four edges."
      },
      {
        "part": "Horizontal card rail",
        "prompt": "A 340svh stage on cream. Absolutely position a heading and a mono hint at the top. Lay six cards in a flex row that does NOT wrap, each flex: 0 0 clamp(230px,26vw,330px), with a 1.5px ink border, an off-white fill, a generated plate canvas at 3/4 aspect, an Anton title and a mono type plus a red price. Translate the row by calc(-1 * progress * overflowWidth) where overflowWidth is measured as track.scrollWidth minus window.innerWidth, so the last card lands flush at the end of the stage rather than at an arbitrary offset. Run a hairline progress meter with a red fill beneath. Under reduced motion the row must wrap and centre instead of translating."
      },
      {
        "part": "The printed artifact",
        "prompt": "A 420svh stage on the dark ground, split into copy left and artifact right. The artifact is a paper rectangle at 3/4 aspect with a 1.5px ink border, a header block with a mono line and a big Anton name, a generated plate in the middle, and three mono rows at the foot for lot, test result and dates. Drive it with SIX properties: --packet-alpha, --packet-enter (translateY from 38px), --packet-scale (0.78 to 1), --packet-cut (0 to 1), --packet-meter, and --packet-copy-x for the copy column sliding slightly opposite. Derive a phase index from progress and, only when the INDEX changes, light the cues cumulatively, swap the live status line, and fill the printed values (the test result should read 'pending' until phase 1). Lay a dashed 2px ink perforation across the artifact whose translateY and opacity are driven by --packet-cut so it opens at the end. Never write DOM text on every frame, only on an index change."
      },
      {
        "part": "Parallax season band",
        "prompt": "A 300svh stage on cream, content bottom-aligned. Behind it a canvas of 22 stacked contour lines, each a sine of x plus a slower harmonic, every fifth line in red, drifting on time. Parallax the canvas on --season-y from -4% to 4% and --season-scale from 1.10 to 1.055. Over it a headline and three chapters laid in a row, each at 0.3 opacity, with exactly ONE at full opacity selected by floor(progress * 3), so the chapters swap rather than accumulate."
      },
      {
        "part": "Per-atom motion budget",
        "prompt": "Split every headline, lede, manifesto line and statement into per-word inline-block spans that rise 0.42em and fade in on a 38ms incremental delay. Then give every card, card title, card meta, price, table row, table cell, cue, packet row, chapter, chapter label, FAQ summary, hero metadata item, button, nav link and footer line its own data-rev attribute with a --d delay of 40 to 100ms times its index. Reveal them with one IntersectionObserver at threshold 0.12, unobserving on entry. Target roughly 200 independently moving elements. Stage-level choreography alone reads flat no matter how long the page is; the per-word and per-row layer is what makes it feel authored."
      }
    ]
  },
  "special_ui_components": [
    "Paper artifact that prints itself as you scroll, filling in a lot number, a test result and dates, then opening a dashed perforation",
    "Horizontal card rail translated by exactly its own measured overflow width",
    "Sentence filled from grey to ink by a bottom-up clip-path wipe on an exact duplicate",
    "Poster lockup driven by three independent variables for y, scale and alpha",
    "Generated tilled-soil, seed and contour plates, all canvas, no images"
  ],
  "implementation_notes": "Single self-contained HTML file. One Google Fonts link (Anton, Inter, Martian Mono) is the only external request; no images, no icon fonts, no animation library. Declare every animated quantity as a CSS custom property on :root and write them all from ONE scroll listener throttled through requestAnimationFrame with a re-entrancy flag. Read each stage's progress as -rect.top / (rect.height - innerHeight) clamped 0..1 via getBoundingClientRect. Only mutate DOM text or classes when a derived INDEX changes, never per frame. Measure the horizontal rail's travel from scrollWidth minus innerWidth at sync time so it stays correct on resize. Size canvases from getBoundingClientRect times a devicePixelRatio capped at 2. Under prefers-reduced-motion: flatten .stage heights to auto, make pins static, force all word spans and data-rev elements visible, remove every clip-path, wrap the horizontal rail, and fill the progress meters, or content will be left permanently clipped or off-screen."
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
