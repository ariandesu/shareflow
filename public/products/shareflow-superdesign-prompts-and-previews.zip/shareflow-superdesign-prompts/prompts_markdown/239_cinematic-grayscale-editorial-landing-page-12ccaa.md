# Cinematic Grayscale Editorial Landing Page

**Category:** Style  
**Tags:** website, landing-page, portfolio, agency, studio, creative-studio, film, photography, director, cinematic, editorial, grayscale, black-and-white, monochrome, minimalist, franklin-gothic, libre-franklin, single-typeface, hairline-frame, full-bleed-photo, hero, stat-row, scroll-cue, quiet-luxury, desktop, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/6709ee78-15cf-497b-9073-3181cb21f8f8](https://p.superdesign.dev/draft/6709ee78-15cf-497b-9073-3181cb21f8f8)  
**Local Standalone Preview:** `previews/cinematic-grayscale-editorial-landing-page-12ccaa.html`

---

## Architectural & Aesthetic Breakdown
A cinematic, true-grayscale editorial landing page for a creative or film/motion studio. A full-viewport hero pairs a full-bleed black-and-white portrait with a 1px hairline frame box on the right holding a tracked all-caps overline, a two-weight Franklin Gothic headline (bold name + light descriptor), a small "SHOWREEL" label, and a down-arrow scroll cue. Below: an introduction (portrait + serif-free editorial copy + italic byline), a "Body of Work" project grid with tracked-caps captions, a full-bleed cinematic photo band, a four-up stat row split by hairline rules, and a "Selected Recognition" list beside a hairline-framed CTA, closing on a black footer. One typeface (Libre Franklin / Franklin Gothic), black + white + grey only, no accent colour. Reusable for any studio, agency, photographer, or director portfolio.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A cinematic, true-grayscale editorial landing page for a creative studio (film / motion / photography / design). It opens on a full-viewport hero: a full-bleed desaturated black-and-white portrait with a thin top nav (wordmark left, Projects / Studio / Contact right), and on the right third a 1px hairline frame box holding a tracked all-caps overline ('WEAVERS OF LIGHT AND SHADOW'), a two-weight headline (bold studio name + lighter descriptor line, e.g. 'MERIDIAN' / 'Film + Motion Studio'), a small tracked 'SHOWREEL 2024' label bottom-left, and a down-arrow scroll cue bottom-right. Below, an Introduction section pairs a grayscale portrait with a tracked 'INTRODUCTION' eyebrow, a large sans headline, an editorial paragraph, and an italic 'Founder & Creative Director' byline. A soft-grey 'Body of Work' section shows a three-up project grid (each = a grayscale still + tracked-caps title + medium/year caption) with a '2021-PRESENT' marker. A full-bleed cinematic photo band follows. Then a four-up stat row (big numbers + tracked-caps labels) divided by 1px hairline rules. A 'Selected Recognition' section lists press entries with right-aligned meta beside a hairline-framed 'Start the conversation' CTA. It closes on a black footer (copyright + Instagram / Vimeo / LinkedIn).",
  "style": {
    "description": "Cinematic, quiet-luxury editorial minimalism. STRICT true grayscale: black, white, and grey only, with fully desaturated photography as the single source of 'colour', never a hue. ONE typeface doing all the work via weight + size (Libre Franklin / Franklin Gothic): heavy 700 for names and section titles, book 400 (and italic) for descriptors and body. An aggressive scale ratio (hero headline ~72-76px vs 11-12px tracked all-caps labels, no timid mid-sizes). Thin 1px hairlines (frame boxes, stat dividers) are the primary structural device. Generous white space; alternating pure-white and full-bleed-photo and soft-grey sections for rhythm. Motion is restrained: fade/rise on scroll only, no bounce, no colour transitions.",
    "prompt": "Design a single-page, full-viewport landing page in STRICT true grayscale (black #111, white #fff, greys, soft-grey #f4f4f4) with NO accent colour anywhere; the only colour is fully-desaturated (grayscale) cinematic photography. Use ONE typeface only, Libre Franklin (Franklin Gothic feel), and build all hierarchy from weight + size: 700 for names/section titles, 400 (and italic) for descriptors/body. Labels and overlines are 11-12px ALL CAPS, letter-spacing ~0.18em. Keep an aggressive scale ratio (hero ~75px vs labels ~12px). Use thin 1px hairlines for the hero frame box and the stat dividers. Alternate pure-white, full-bleed-photo, and soft-grey sections. Subtle fade/rise on scroll only. Do NOT introduce a second typeface or any accent colour."
  },
  "layout_and_structure": {
    "description": "A vertical scroll: (1) full-viewport hero (full-bleed grayscale portrait + thin nav + right-side hairline frame box with overline/headline/label/scroll-cue), (2) Introduction (portrait left + eyebrow + headline + paragraph + italic byline right), (3) soft-grey Body of Work (section title + '2021-PRESENT' marker + three-up project grid), (4) full-bleed cinematic photo band, (5) four-up stat row split by 1px hairline rules, (6) Selected Recognition list beside a hairline-framed CTA, (7) black footer. Reflows to one column on mobile; the project and stat grids stack.",
    "prompts": [
      {
        "part": "Nav + Hero",
        "prompt": "Full viewport (100vh). Full-bleed desaturated black-and-white portrait (dramatic side light, subject looking toward camera). A thin transparent top nav: bold wordmark left, tracked-caps links (Projects / Studio / Contact) right, all white. On the right ~third, a 1px white hairline border box containing: a small tracked all-caps overline ('WEAVERS OF LIGHT AND SHADOW'), a two-weight headline at ~75px (studio name in 700 + a descriptor line in 400, e.g. 'MERIDIAN' / 'Film + Motion Studio'), a small tracked 'SHOWREEL 2024' label bottom-left of the box, and a white down-arrow scroll cue bottom-right."
      },
      {
        "part": "Introduction",
        "prompt": "White section. Left: a portrait-orientation grayscale photo. Right: a tracked-caps 'INTRODUCTION' eyebrow, a large (~30px) 700 sans headline (2-3 lines), a ~14px grey editorial paragraph, and an italic 400 byline ('Founder & Creative Director - [Name]')."
      },
      {
        "part": "Body of Work",
        "prompt": "Soft-grey (#f4f4f4) section. A large 700 'Body of Work' title with a right-aligned tracked-caps '2021-PRESENT' marker, then a three-column project grid: each card = a landscape grayscale still, a tracked-caps title ('ETHEREAL PLANES'), and a medium/year caption ('NARRATIVE SHORT - 2023')."
      },
      {
        "part": "Cinematic band",
        "prompt": "A full-bleed, edge-to-edge desaturated cinematic photo band (e.g. a film projector in a dark, smoky room) with no text - a visual breath between sections."
      },
      {
        "part": "Accolades",
        "prompt": "White section. A single row of four stat blocks divided by 1px vertical hairline rules (with hairlines above and below the row): each = a big 700 number ('12', '85+', '09', '14') and a tiny tracked-caps label ('GLOBAL AWARDS', 'FILM PRODUCTIONS', 'YEARS IN MOTION', 'FESTIVAL LAURELS')."
      },
      {
        "part": "Recognition + CTA",
        "prompt": "Soft-grey section, two columns. Left: a tracked-caps 'SELECTED RECOGNITION' eyebrow over a list of press rows (bold publication left, grey meta right, e.g. 'VOGUE CINEMATIC ... Artist Profile / 2024') separated by hairlines. Right: a 1px hairline-framed CTA box echoing the hero box - a tracked-caps 'WORK WITH US' label, a large 700 'Start the conversation' headline, and a tracked-caps 'CONNECT ->' link."
      },
      {
        "part": "Footer",
        "prompt": "A black footer band: small grey copyright left ('\u00a9 2024 [Studio]. All rights reserved.'), tracked-caps social links right (Instagram / Vimeo / LinkedIn)."
      }
    ]
  },
  "special_ui_components": [
    {
      "component": "Hairline hero frame box",
      "description": "A 1px-bordered container grouping all hero text against the photo.",
      "prompt": "On the right third of the hero, a container with a 1px hairline border (white at ~35% opacity over the photo). Inside, stack a tracked all-caps overline, a two-weight headline (bold name + lighter descriptor line), a small-caps label pinned bottom-left, and a down-arrow scroll cue bottom-right."
    },
    {
      "component": "Two-weight single-typeface headline",
      "description": "Hierarchy from weight, not a second font.",
      "prompt": "Set the studio name in Libre Franklin 700 and the descriptor line in Libre Franklin 400 (or 400 italic), same ~75px size, stacked on two lines. Never introduce a second typeface."
    },
    {
      "component": "Tracked all-caps labels",
      "description": "Editorial furniture: eyebrows, captions, nav, section labels.",
      "prompt": "Render eyebrows, section labels, nav links and captions at 11-12px, uppercase, letter-spacing ~0.18em, in muted grey or white."
    },
    {
      "component": "Hairline-divided stat row",
      "description": "A four-up metrics row separated by 1px rules.",
      "prompt": "A single row of four stat blocks divided by 1px vertical hairline rules, with hairlines above and below the row; each block = a big 700 number over a tiny tracked-caps label."
    },
    {
      "component": "Full-bleed grayscale photo band",
      "description": "An edge-to-edge desaturated image used as a section break.",
      "prompt": "A 100%-width, fixed-height cinematic photo fully desaturated (filter: grayscale(1)) with no text - a visual breath between content sections."
    },
    {
      "component": "Hairline-framed CTA echo",
      "description": "A closing CTA that repeats the hero's framed box.",
      "prompt": "A 1px hairline-bordered box mirroring the hero frame: a tracked-caps label, a large 700 headline ('Start the conversation'), and a tracked-caps 'CONNECT ->' link."
    }
  ]
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
