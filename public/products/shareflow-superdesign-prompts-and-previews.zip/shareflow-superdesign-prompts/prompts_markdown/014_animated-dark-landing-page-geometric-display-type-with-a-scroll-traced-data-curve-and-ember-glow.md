# Animated Dark Landing Page: Geometric Display Type With a Scroll-Traced Data Curve and Ember Glow

**Category:** Animation  
**Tags:** landing, landing-page, animated, animation, scroll-animation, scroll-pinned, sticky, clip-path, wipe, canvas, data-visualisation, chart, geometric, unbounded, manrope, dark-mode, ember, red, orange, workshop, studio, craft, manufacturing, industrial, maker, desktop, responsive  
**Price:** ৳49 BDT (SupportKori: https://www.supportkori.com/mhr3d)  
**Live Preview:** [https://p.superdesign.dev/draft/8a2fd822-bd58-4d93-8f5d-b0f9347a07e6](https://p.superdesign.dev/draft/8a2fd822-bd58-4d93-8f5d-b0f9347a07e6)  
**Local Standalone Preview:** `previews/animated-dark-landing-page-geometric-display-type-with-a-scroll-traced-data-curve-and-ember-glow.html`

---

## Architectural & Aesthetic Breakdown
An animated, dark LANDING PAGE built on a wide geometric display face and one ember accent: ink #070908, bone #e9ede6, ember #e44b3c, with Unbounded for headlines and Manrope for everything else. Four sections pin as you scroll. A hero over a screen-blended molten glow field of drifting radial gradients. A statement filled LEFT TO RIGHT by a scroll-driven clip-path. A live data curve that traces itself as you scroll, with a readout computed from the curve so the number and the highlighted row can never disagree. A wobbling molten form that scales up behind a closing line. Every headline splits into per-word spans and roughly 180 elements move independently. No images, no animation library. Reusable for a workshop, foundry, roastery, lab, manufacturer or any technical craft business with a process that has measurable stages.

---

## Production System Prompt Specification
Copy and paste this into Cursor Composer, Claude 3.5 Sonnet, v0, Bolt.new, or Windsurf:

```markdown
{
  "summary": "A scroll-choreographed dark LANDING page for a technical craft business (built here as 'Cullet', a hot glass workshop). Ink #070908 ground with #0d1110 and #101412 for the alternate pins, bone #e9ede6 text, mist #a9b5b2 for secondary, and ember #e44b3c as the only chroma. Unbounded 600 carries every headline at letter-spacing -.05em to -.075em; Manrope 300 carries body and 500 carries furniture at +.2em uppercase. FOUR pinned stages: (1) a hero over a canvas of five drifting radial ember gradients in mix-blend-mode: screen, whose opacity rises with stage progress while the lockup lifts and fades, with one half of the wordmark in ember; (2) a wipe stage where a large statement sits at 16 percent bone and an exact absolutely-positioned clone of it is revealed LEFT TO RIGHT by clip-path: inset(0 calc(100% - p*100%) 0 0), with an ember rule filling underneath it in step; (3) the curve stage, where five process rows light cumulatively down the left while a canvas on the right draws a piecewise cooling curve, traces it in ember only as far as the scroll has travelled, pulses a dot at the head of the trace, and prints a large readout computed from the curve at that exact progress; (4) a gather stage where three nested wobbling molten forms, built from summed sines around a polar loop and filled with radial ember gradients, scale from 0.72 to 1.22 behind a closing line. Then normal bands: a three-column explainer, a commission table of ruled rows with ember figures, and an FAQ. Every headline, lede and column splits into per-word spans on a 36ms stagger and every row, cell and strap carries its own delay, so roughly 180 elements move independently, all driven by ONE rAF-throttled scroll handler writing CSS custom properties.",
  "style": {
    "description": "Geometric dark. A wide rounded display face against a light neutral sans, one ember accent used as heat rather than as branding, hairline rules at 8 to 16 percent, zero radii and no shadows. The only texture is generated light: screen-blended radial gradients that read as something molten just out of frame.",
    "prompt": "Palette: ink #070908 ground, #0d1110 and #101412 for alternate pinned stages, bone #e9ede6 for text with #dfe4dd as a second tone, mist #a9b5b2 for secondary copy, ember #e44b3c as the single accent. Hairlines rgba(233,237,230,.16) and .08. Typography: Unbounded at 600 for every headline, wordmark and numeral, letter-spacing -.05em on headlines and -.075em on the poster; Manrope 300 for body at 15px/1.6 and Manrope 500 at clamp(.8rem,1vw,1rem) with letter-spacing .2em uppercase for all furniture. Radii 0, no shadows, no photography. Generated light only: draw radial ember gradients on canvas and composite with mix-blend-mode: screen, never as a CSS glow box. Ration ember to: half the wordmark, the process temperatures, the curve trace, the rules, the prices and one button. Ease with cubic-bezier(.16,1,.3,1); reserve cubic-bezier(.65,0,.35,1) for anything that should feel mechanical rather than soft."
  },
  "layout_and_structure": {
    "description": "Four tall pinned stages (280svh to 380svh), each a position:sticky inner at top:0, height:100svh, overflow:hidden, then two normal bands. Every animated quantity is a CSS custom property written by ONE rAF-throttled scroll handler.",
    "prompts": [
      {
        "part": "Molten glow hero",
        "prompt": "A 300svh stage. A full-bleed canvas draws five radial gradients in ember at 16 to 28 percent alpha, each drifting on its own sine of time, composited with mix-blend-mode: screen so they add rather than cover; raise the canvas opacity from .55 to 1.0 across the stage. The lockup lifts 52px and fades. Split the wordmark so its second half is ember. SIZE THE WORDMARK FROM ITS CHARACTER COUNT AND THE FACE'S OWN WIDTH: font-size: min(clamp(3rem,37vw,22rem), calc(90vw / (chars * .68))). Unbounded is a WIDE geometric face at roughly .68em average advance, against .44em for a condensed grotesque like Anton, so a vw value tuned on a condensed face will overflow badly here. Because the pin is overflow:hidden, that clipping is invisible to a document-level overflow test; check the line's own scrollWidth against its clientWidth."
      },
      {
        "part": "Left-to-right wipe",
        "prompt": "A 280svh stage. One statement at clamp(1.9rem,6.4vw,5.4rem) over 15ch, set in bone at 16 percent. Overlay an EXACT absolutely-positioned duplicate in full bone, clipped with clip-path: inset(0 calc(100% - var(--p) * 100%) 0 0) so it fills left to right as the stage scrubs. Underneath, a hairline rule with an ember fill whose width tracks the same progress. Verify the clone's bounding rect matches its base to 0px on x, y and width, or the fill will visibly disagree with the text beneath it. Multiply the progress by about 1.2 and clamp, so the sentence completes slightly before the stage ends rather than exactly at the last pixel."
      },
      {
        "part": "Scroll-traced data curve",
        "prompt": "A 380svh stage, two columns. Left: a headline with an ember clause, then five ruled rows carrying a measured value in ember display type, a bold label and a muted note, at 0.28 opacity, lighting cumulatively as floor(p * 5) advances. Right: a bordered plot with a canvas. Define the series as an array of real values and interpolate piecewise between them; draw the full curve once in bone at 22 percent, then draw it AGAIN in ember at 2.4px only from 0 to the current progress, and put a pulsing dot with a soft halo at the head of the trace. Print a large readout in the corner computed as the interpolated value AT the current progress, so the number, the trace head and the highlighted row are the same fact rendered three ways and cannot disagree. This is the difference between a mechanic and a caption."
      },
      {
        "part": "Scaling molten form and bands",
        "prompt": "A 300svh stage, content bottom-aligned, with three nested closed forms drawn on canvas: for each, walk a polar loop and modulate the radius by two summed sines of the angle and time, fill with a radial ember gradient at 16 percent falling to 0, and stroke at 34 percent. Scale the whole canvas from 0.72 to 1.22 on stage progress with mix-blend-mode: screen. Then normal bands: a three-column explainer, a commission table of ruled rows (name, muted description, ember figure) collapsing to two columns under 700px, and an FAQ of native details rows with a CSS-only plus."
      },
      {
        "part": "Per-atom motion budget",
        "prompt": "Split every headline, statement, lede and column paragraph into per-word inline-block spans rising 0.4em on a 36ms incremental delay. Give every explainer column, column title, table row, table cell, process row label, process value, process note, FAQ summary, hero strap, wipe footer item, button, nav link and footer line its own data-rev attribute with a --d delay of 40 to 100ms times its index, revealed by one IntersectionObserver at threshold 0.12. Target roughly 180 independently moving elements."
      }
    ]
  },
  "special_ui_components": [
    "Data curve that traces itself to scroll position with a readout computed from the curve, so the number and the highlighted row cannot disagree",
    "Left-to-right clip-path wipe filling an exact clone of a statement, with an ember rule tracking it",
    "Screen-blended molten glow field of drifting radial gradients, drawn on canvas rather than CSS glow",
    "Nested wobbling forms from summed sines around a polar loop, scaling on scroll"
  ],
  "implementation_notes": "Single self-contained HTML file. One Google Fonts link (Unbounded, Manrope) is the only external request; no images, no icon fonts, no animation library. Drive every animated quantity as a CSS custom property written from ONE scroll listener throttled through requestAnimationFrame with a re-entrancy flag; read stage progress with getBoundingClientRect as -rect.top / (rect.height - innerHeight) clamped 0..1. Only mutate DOM text or classes when a derived INDEX changes, never per frame, but the canvas may read the continuous progress every frame since it is redrawing anyway. Size canvases from getBoundingClientRect times a devicePixelRatio capped at 2 and re-fit on resize. Note that per-character advance differs sharply by face: budget about .68em for a wide geometric like Unbounded, .60em for a Didone, .56em for a condensed variable grotesque and .44em for Anton, and size poster lines from the real character count rather than a fixed vw. Under prefers-reduced-motion: flatten stage heights, make pins static, remove the wipe clip-path, freeze the curve at full trace, and force every word span and data-rev element visible."
}
```

---
*Generated by ShareFlow Design Prompt Library · © 2026 Mahir Faisal (MHR3D)*
