import logging
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from config import TELEGRAM_BOT_TOKEN
from database import init_db
from handlers.start import start_handler
from handlers.help import help_handler
from handlers.stats import stats_handler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

async def main():
    await init_db()
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    
    app.add_handler(CommandHandler('start', start_handler))
    app.add_handler(CommandHandler('help', help_handler))
    app.add_handler(CommandHandler('stats', stats_handler))
    
    print('⚡ Async Telegram Bot Engine is running...')
    await app.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
