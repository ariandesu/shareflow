from telegram import Update
from telegram.ext import ContextTypes
from database import add_user

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await add_user(user.id, user.username or '', user.first_name or '')
    await update.message.reply_html(
        f"👋 Welcome <b>{user.first_name}</b>!\n\n"
        f"⚡ Powered by <b>ShareFlow Async Telegram Bot Starter Kit</b>.\n"
        f"Type /help to see all available commands."
    )
