from telegram import Update
from telegram.ext import ContextTypes
import aiosqlite
from config import DB_PATH

async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute('SELECT COUNT(*) FROM users') as cursor:
            count = (await cursor.fetchone())[0]
    await update.message.reply_text(f"📊 Total Registered Users: {count}")
