from telegram import Update
from telegram.ext import ContextTypes

async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📌 Available Commands:\n"
        "/start - Initialize bot & register user\n"
        "/help - Display help guide\n"
        "/stats - View bot system metrics"
    )
