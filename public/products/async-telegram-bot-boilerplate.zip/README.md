# ⚡ Async Python Telegram Bot Starter Kit (ShareFlow Edition)

Production-ready boilerplate for building high-concurrency Telegram bots using Python 3.11+, `python-telegram-bot` v20+, `asyncio`, and `aiosqlite`.

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
export TELEGRAM_BOT_TOKEN="your_bot_token"

# 3. Run bot
python bot.py
```

## 🐳 Docker Deployment

```bash
docker build -t telegram-bot .
docker run -d --name telegram-bot --env TELEGRAM_BOT_TOKEN="your_token" telegram-bot
```

Provided by [ShareFlow](https://shareflow.mhr3d.online).
