# HealthTech AI Diagnostics & Clinical Co-Pilot
**Category:** Landing Page
**Target Tool:** Universal
**Price:** ৳49 BDT (SupportKori)
**Commercial License:** Yes, unlimited client and commercial use.

---

## 1. System Persona & Behavioral Constraints
When generating this interface, adopt the following strict rules:
- **Role:** You are a World-Class Principal Design Engineer specialized in modern Apple-inspired and Stripe-grade web interfaces.
- **Frameworks:** React 18+, TypeScript, Tailwind CSS v4, Lucide React icons, and Framer Motion.
- **Aesthetic Principles:**
  - High typographic hierarchy using clean sans-serif (Inter, Plus Jakarta Sans, SF Pro).
  - Dark mode first: slate black background (`#0b0c0e`), frosted glass cards (`rgba(18, 20, 26, 0.75)` with `backdrop-blur-xl`), and crisp 1px borders (`border-white/10`).
  - Accent Color: Primary highlight is `#0d9488`.
  - Zero placeholder text: Write authentic, production-grade micro-copy that directly matches the product's value proposition.
  - Mobile Responsiveness: 100% responsive down to 360px mobile viewports.

---

## 2. Architectural Blueprint & Component Structure
Build the complete, self-contained component according to these specifications:
- **Container:** Full viewport height container (`min-h-screen w-full flex flex-col justify-between`) with subtle background glow.
- **Header:** Sticky frosted glass header with brand mark, category tag `Landing Page`, and action status pill.
- **Hero / Core Viewport:**
  - Headline: "HealthTech AI Diagnostics & Clinical Co-Pilot"
  - Subheadline: "Augmenting Clinicians with 99.4% Diagnostic Precision"
  - Key Features to Render:
    - Medical vitals telemetry waveform
    - FDA/HIPAA regulatory trust seals
    - Clinical trial outcome metrics
    - Secure provider portal gateway
- **Interactive States:**
  - Hover states on interactive cards (`hover:border-white/20 transition-all duration-300`).
  - Active button states with subtle scaling (`active:scale-95`).
  - Clear visual contrast for primary CTA versus secondary ghost buttons.
- **Footer / Meta Ribbon:** Minimalist status bar displaying operational telemetry and copyright.

---

## 3. Ready-to-Paste Prompt for Universal
```markdown
Create a production-grade, highly polished React component for a "HealthTech AI Diagnostics & Clinical Co-Pilot".
The design must follow modern Cupertino glassmorphic standards:
- Dark slate background (#0b0c0e) with frosted glass cards (backdrop-blur-xl bg-white/[0.04] border border-white/10).
- Accent highlights in #0d9488.
- Include realistic copy and live data for: Serene, clinical-grade digital health landing page with reassuring emerald accents, patient telemetry graph, and HIPAA security compliance..
- Implement key features: Medical vitals telemetry waveform, FDA/HIPAA regulatory trust seals, Clinical trial outcome metrics, Secure provider portal gateway.
- Ensure full responsiveness with Lucide React icons and smooth hover animations.
Output clean, modular TypeScript with Tailwind CSS classes.
```
