# Clinical Botanical Skincare & Active Serums
**Category:** E-Commerce
**Target Tool:** Lovable
**Price:** ৳49 BDT (SupportKori)
**Commercial License:** Yes, unlimited client and commercial use.

---

## 1. System Persona & Behavioral Constraints
When generating this interface, adopt the following strict rules:
- **Role:** You are a World-Class Principal Design Engineer specialized in modern Apple-inspired and Stripe-grade web interfaces.
- **Frameworks:** React 18+, TypeScript, Tailwind CSS v4, Lucide React icons, and Framer Motion.
- **Aesthetic Principles:**
  - High typographic hierarchy using clean sans-serif (Inter, Plus Jakarta Sans, SF Pro).
  - Dark mode first: slate black background (`#0b0c0e`), frosted glass cards (`rgba(18, 20, 26, 0.75)` with `backdrop-blur-xl`), and crisp 1px borders (`border-white/10`).
  - Accent Color: Primary highlight is `#0284c7`.
  - Zero placeholder text: Write authentic, production-grade micro-copy that directly matches the product's value proposition.
  - Mobile Responsiveness: 100% responsive down to 360px mobile viewports.

---

## 2. Architectural Blueprint & Component Structure
Build the complete, self-contained component according to these specifications:
- **Container:** Full viewport height container (`min-h-screen w-full flex flex-col justify-between`) with subtle background glow.
- **Header:** Sticky frosted glass header with brand mark, category tag `E-Commerce`, and action status pill.
- **Hero / Core Viewport:**
  - Headline: "Clinical Botanical Skincare & Active Serums"
  - Subheadline: "10% Niacinamide + Zinc Daily Barrier Restorer"
  - Key Features to Render:
    - Active clinical ingredient percentage pills
    - AM / PM routine placement step indicator
    - Dermatologist tested & fragrance-free seals
    - Before-and-after clinical trial statistics
- **Interactive States:**
  - Hover states on interactive cards (`hover:border-white/20 transition-all duration-300`).
  - Active button states with subtle scaling (`active:scale-95`).
  - Clear visual contrast for primary CTA versus secondary ghost buttons.
- **Footer / Meta Ribbon:** Minimalist status bar displaying operational telemetry and copyright.

---

## 3. Ready-to-Paste Prompt for Lovable
```markdown
Create a production-grade, highly polished React component for a "Clinical Botanical Skincare & Active Serums".
The design must follow modern Cupertino glassmorphic standards:
- Dark slate background (#0b0c0e) with frosted glass cards (backdrop-blur-xl bg-white/[0.04] border border-white/10).
- Accent highlights in #0284c7.
- Include realistic copy and live data for: Clean dermatological skincare showcase with active ingredient percentages (2% Salicylic, 10% Niacinamide), skin type filters, and routine steps..
- Implement key features: Active clinical ingredient percentage pills, AM / PM routine placement step indicator, Dermatologist tested & fragrance-free seals, Before-and-after clinical trial statistics.
- Ensure full responsiveness with Lucide React icons and smooth hover animations.
Output clean, modular TypeScript with Tailwind CSS classes.
```
